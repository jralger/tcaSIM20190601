function [handles, A] = ReadUpdateAllOneCarbonIsotopomers(handles)

[o, x] = DefineOneCarbonLabelIndices();
A = zeros(1,2);

A(1, x) = str2double(handles.X.String);

A = UpdateUnLabelledIsotopomer(A);

if A(1, o) < 0
    A = zeros(1, 2);
    A = UpdateUnLabelledIsotopomer(A);
end

handles.O.String = sprintf('%4.2f', A(1, o));
handles.X.String = sprintf('%4.2f', A(1, x));

end
