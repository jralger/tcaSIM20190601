function DisplayDumpMolResults(MolID, Mol, ExptID, ODN, VersionID, ...
                               SkipAnimation, SkipStackedMultipletPlots, ...
                               SkipMolDiagram)

LMolID = SetLongMolID(MolID);

nTCAturns = size(Mol,1);

C13Display(MolID, Mol, ExptID, ODN);

FN = [ODN, filesep, ExptID, '_', MolID, '_Isotops.csv'];
DumpOneIsotopmerEnrichmentToCSV(Mol, LMolID, FN, ExptID, VersionID);

if SkipMolDiagram == 0
    Title = ['Expt ', ExptID, ': ', LMolID, ' Isotopomers at Final Turn'];
    DisplayMolLabels(MolID, Mol, Title, 1);
    FN = [ODN, filesep, ExptID, '_', MolID, '_IsotopsAll_FinalTurn.png'];
    H = gcf;
    saveas(H, FN);
    close;
    
    Title = ['Expt ', ExptID, ': Non-zero ', LMolID, ' Isotopomers at Final Turn'];
    DisplayMolLabels(MolID, Mol, Title, 0);
    FN = [ODN, filesep, ExptID, '_', MolID, '_IsotopsNonZero_FinalTurn.png'];
    H = gcf;
    saveas(H, FN);
    close;
end

FN = [ODN, filesep, ExptID, '_', MolID, '_MassSpectrum.csv'];
DumpOneMassTimeSeriesToCSV(Mol, LMolID, FN, ExptID, VersionID);

Mass = Isotopomers2Isotopologues(Mol);
Title = ['Expt ', ExptID, ': ', LMolID, ' Mass Spectrum'];
figure('Color', 'w', 'Position', [50, 50, 1024, 1024]);
BarPlotMass(Mass, nTCAturns , Title, 'r');
FN = [ODN, filesep, ExptID, '_', MolID, '_MassSpectrum_FinalTurn.png'];
H = gcf;
saveas(H, FN);
close;

Title = ['Expt ', ExptID, ': ', LMolID, ' Isotopomer Distribution'];
if SkipAnimation == 0
    FN = [ODN, filesep, ExptID, '_', MolID, '_IsotopsBarGraphMovie.mp4'];
    BarhIsotopomerMovie(Mol, Title, 'b', FN);
    FN = [ODN, filesep, ExptID, '_', MolID, '_IsotopsBarGraph_FinalTurn.png'];
    H = gcf;
    saveas(H, FN);
    close;
end
if SkipAnimation == 1
    figure('Color', 'w', 'Position', [50, 50, 1024, 1024]);
    BarhPlotIsotopomerEnrichment(Mol, nTCAturns, Title, 'b');
    FN = [ODN, filesep, ExptID, '_', MolID, '_IsotopBarGraph_FinalTurn.png'];
    H = gcf;
    saveas(H, FN);
    close;
end

FN = [ODN, filesep, ExptID, '_', MolID,'_Multiplets.csv'];
DumpOneMultipletTimeSeriesToCSV(Mol, LMolID, FN, ExptID, VersionID);

if SkipStackedMultipletPlots == 0
%     txt = 'Please wait. 13C NMR spectral simulations in progress';
%     h = waitbar(2, txt);
    h = StackedMultipletsMsgBox();
    Mults = BuildDefaultMultiplets(MolID);
    V = Mol(nTCAturns, :);
    Mults = SimulateMolSpectra(MolID, Mults, V);
    BMPDN = [ODN, filesep, ExptID];
    close(h);
    R = DisplaySaveStackedMultipletSpectra(BMPDN, Mults);
end






end

