function BarhPlotIsotopomerEnrichment(A, m, Title, C)
V = A(m, :);
nV = size(V, 2);
xos = BuildIsotopomerIDs(nV);

barh(V, C);
maxA = max(A);
maxA = max(maxA);
if maxA == 0
    maxA = 1;
end
axis([0, maxA, 0, nV+1]);

title(Title);

set(gca, 'YTick', 1:nV);
set(gca, 'YTickLabel', xos);
set(gca, 'TickDir', 'out');
set(gca, 'Box', 'off');

xlabel('Enrichment');
ylabel('Isotopomer');

end

