function DumpOneIsotopmerEnrichmentToCSV(M, MID, FN, ExptID, VersionID)
nIsotopomers = size(M, 2);
nTCAturns = size(M,1);

fileID = fopen(FN, 'w');
txt = 'tcaSIM Isotopomer Simulation\n';
fprintf(fileID, txt);

WritePreambleTCAS(fileID, VersionID, ExptID);

txt = ',,,,Isotopomer Fraction At Turn Number\n';
fprintf(fileID, txt);

txt = 'MoleculeID,IsotopomerNumber,LabelPattern,LabelPattern,';
for i=1:nTCAturns
    txt = [txt,num2str(i),','];
end
txt = [txt,'\n'];
fprintf(fileID, txt);

IDs = BuildIsotopomerIDs(nIsotopomers);

for i = 1:nIsotopomers
    txt = [MID, ','];
    txt = [txt, num2str(i), ','];
    T = char(IDs(i));
    txt = [txt, T, ','];
    txt = [txt, MJID(T), ','];
    V = M(:, i);
    for j = 1:nTCAturns
        txt = [txt, num2str(V(j)), ','];
    end
    txt = [txt, '\n'];
    fprintf(fileID, txt);
end
fclose(fileID);
end

