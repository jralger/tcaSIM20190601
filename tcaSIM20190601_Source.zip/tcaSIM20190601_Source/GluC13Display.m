function varargout = GluC13Display(varargin)

% Last Modified by GUIDE v2.5 14-Aug-2018 03:30:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GluC13Display_OpeningFcn, ...
                   'gui_OutputFcn',  @GluC13Display_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GluC13Display is made visible.
function GluC13Display_OpeningFcn(hObject, eventdata, handles, varargin)
h = SimMsgBox();
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
PPMW = 2.0;
GluMults = BuildGluDefaultMultiplets();

T = SetDefaultChemicalShifts();
FreqsPPM = T.GluEstFreqsPPM;

Glu = cell2mat(varargin(1));
ExptID = char(varargin(2));
ODN = char(varargin(3));
nTurns = size(Glu, 1);

for i = 1:nTurns
    V = Glu(i,:);
    GluMults = SimulateGluSpectra(GluMults, V);
    CWS = GetSpectrumFromMultiplets(GluMults, PPMW);
    SA(1, i) = CWS;
end

FEs = zeros(nTurns, 5);
for i = 1:nTurns
    V = Glu(i,:);
    FE = GetFractionalEnrichment(V);
    FEs(i,:) = FE;
end

TurnNumber = round(nTurns/2);
handles.edit1.String = num2str(TurnNumber);

Axs = [handles.axes1, handles.axes3, handles.axes4, handles.axes6, ...
       handles.axes5, handles.axes2, handles.axes7, handles.axes8];
UpdateGluC13Display(TurnNumber, Axs, Glu, SA, ...
                             PPMW, FEs, FreqsPPM, ExptID);
handles.ExptID = ExptID;
handles.TurnNumber = TurnNumber;
handles.Glu = Glu;
handles.FEs = FEs;
handles.SA = SA;
handles.FreqsPPM = FreqsPPM;
handles.PPMW = PPMW;
handles.ODN = ODN;
guidata(hObject, handles);

% UIWAIT makes GluC13Display wait for user response (see UIRESUME)
close(h);
uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GluC13Display_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;
close;


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
Spos = get(hObject,'Value');
ExptID = handles.ExptID;
Glu = handles.Glu;
FEs = handles.FEs;
SA = handles.SA;
FreqsPPM = handles.FreqsPPM;
nTurns = size(Glu, 1);
TurnNumber = round(Spos*nTurns);
if TurnNumber < 1
    TurnNumber = 1;
end

handles.edit1.String = num2str(TurnNumber);

Axs = [handles.axes1, handles.axes3, handles.axes4, handles.axes6, ...
       handles.axes5, handles.axes2, handles.axes7, handles.axes8];
PPMW = handles.PPMW;
UpdateGluC13Display(TurnNumber, Axs, Glu, SA, ...
                             PPMW, FEs, FreqsPPM, ExptID);

                         
% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
     set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
Glu = handles.Glu;
FEs = handles.FEs;
SA = handles.SA;
FreqsPPM = handles.FreqsPPM;
ExptID = handles.ExptID;

nTurns = size(Glu, 1);
TurnNumber = nTurns;

handles.edit1.String = num2str(TurnNumber);
handles.TurnNumber = TurnNumber;

handles.slider1.Value = TurnNumber/nTurns;

Axs = [handles.axes1, handles.axes3, handles.axes4, handles.axes6, ...
       handles.axes5, handles.axes2, handles.axes7, handles.axes8];
PPMW = handles.PPMW;
UpdateGluC13Display(TurnNumber, Axs, Glu, SA, ...
                             PPMW, FEs, FreqsPPM, ExptID);                     
ExptID = handles.ExptID;
ODN = handles.ODN;
if ~strcmp(ODN, 'Null');
   FN = [ODN, filesep, ExptID, '_Glu_Summary.png'];    
   H = gcf;
   H.PaperPositionMode = 'auto';
   print(FN,'-dpng','-r0')
end
uiresume(handles.figure1);


function edit1_Callback(hObject, eventdata, handles)

TurnNumber = str2double(get(hObject,'String'));
TurnNumber = round(TurnNumber);

Glu = handles.Glu;
FEs = handles.FEs;
SA = handles.SA;
FreqsPPM = handles.FreqsPPM;
ExptID = handles.ExptID;

nTurns = size(Glu, 1);
if TurnNumber < 1
    TurnNumber = 1;
end
if TurnNumber > nTurns
    TurnNumber = nTurns;
end

handles.edit1.String = num2str(TurnNumber);
handles.TurnNumber = TurnNumber;

handles.slider1.Value = TurnNumber/nTurns;

Axs = [handles.axes1, handles.axes3, handles.axes4, handles.axes6, ...
       handles.axes5, handles.axes2, handles.axes7, handles.axes8];
PPMW = handles.PPMW;
UpdateGluC13Display(TurnNumber, Axs, Glu, SA, ...
                             PPMW, FEs, FreqsPPM, ExptID);


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function axes8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes8
