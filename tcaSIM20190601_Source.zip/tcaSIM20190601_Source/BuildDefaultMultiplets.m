function Mults = BuildDefaultMultiplets(MolID)

if strcmp(MolID, 'Glu')
    Mults = BuildGluDefaultMultiplets();
end

if strcmp(MolID, 'Asp')
    Mults = BuildAspDefaultMultiplets();
end

if strcmp(MolID, 'bHB')
    Mults = BuildbHBDefaultMultiplets();
end

if strcmp(MolID, 'Ala')
    Mults = BuildAlaDefaultMultiplets();
end

if strcmp(MolID, 'Glc')
    Mults = BuildGlcDefaultMultiplets();
end

if strcmp(MolID, 'MAG')
    Mults = BuildMAGDefaultMultiplets();
end

end

