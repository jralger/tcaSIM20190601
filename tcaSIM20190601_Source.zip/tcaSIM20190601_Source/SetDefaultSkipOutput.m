function SkipOutput = SetDefaultSkipOutput()

SkipOutput.SkipAnimation = 1;
SkipOutput.MultStackedPlots = 1;
SkipOutput.MolLabelDiagram = 1;
SkipOutput.Glu = 0;
SkipOutput.Ala = 1;
SkipOutput.Asp = 1;
SkipOutput.bHB = 1;
% SkipGlcOutput = SkipOutput.Glc;
SkipOutput.MAG = 1;





end

