function SimplePlotSpectrum(Spectrum, PPMR, YR, txt)
X = Spectrum.PPMTable;
Y = Spectrum.FreqDomainData;
Y = real(Y);

maxY = max(Y);
PYH = 1.1*maxY;
PYL = -0.1*maxY;

Z = Y*0.0;
plot(X, Z, 'k--', 'LineWidth',0.5);
hold on;
plot(X, Y, 'r-', 'LineWidth',2);
if YR(1) == 0 || YR(2) == 0
    YR(1) = -0.1;
    YR(2) = 0.1;
end
axis([PPMR(1), PPMR(2), YR(1), YR(2)]);
xlabel('PPM', 'FontSize', 9);
box off;
ax = gca;
ax.XDir = 'reverse';
ax.YAxis.Visible = 'off';
xtickformat('%,.1f');
ax.TickDir = 'out';
title(txt);
end

