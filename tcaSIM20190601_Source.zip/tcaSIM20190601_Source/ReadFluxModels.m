function V = ReadFluxModels(FN, ID, C2N)
V = 'Null';
fileID = fopen(FN, 'r');
A = 'A';
while ischar(A)
      A = fgetl(fileID);
      if ischar(A)
          B = strsplit(A, ',');
          nB = size(B, 2);
          if strcmp(B(1), ID)
             fclose(fileID);
             V = B(2:nB);
             if C2N == 1
                 T = V;
                 nV = size(V, 2);
                 V = zeros(1, nV);
                 for i = 1:nV
                     V(1, i) = str2num(char(T(1,i)));
                 end
             end
             return
          end
      end
end          
fclose(fileID);
end

