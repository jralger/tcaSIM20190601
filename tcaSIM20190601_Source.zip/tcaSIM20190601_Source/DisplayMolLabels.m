function DisplayMolLabels(MolID, Mol, Title, ShowAll)

if strcmp(MolID, 'Glu')
    DisplayGluLabels(Mol, Title, ShowAll);
end

if strcmp(MolID, 'Asp')
    DisplayAspLabels(Mol, Title, ShowAll);
end

if strcmp(MolID, 'bHB')
    DisplayAspLabels(Mol, Title, ShowAll);
end

if strcmp(MolID, 'Ala')
    DisplayAlaLabels(Mol, Title, ShowAll);
end

if strcmp(MolID, 'Glc')
    DisplayGlcLabels(Mol, Title, ShowAll);
end

if strcmp(MolID, 'MAG')
    DisplayMAGLabels(Mol, Title, ShowAll);
end

end

