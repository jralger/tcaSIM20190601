function UpdateMAGC13Display(TurnNumber, Axs, MAG, SA, ...
                             PPMW, FEs, FreqsPPM, ExptID)
CWS = SA(1, TurnNumber);
FE = FEs(TurnNumber,:);
PPML = 0.0;
PPMH = 200.0;
PPMR = [PPML, PPMH];
Y = CWS.FreqDomainData;
Y = real(Y);
maxY = max(Y);
YR = [-0.1*maxY, 1.1*maxY];
axidx = 1;
axes(Axs(axidx));
cla;
txt = ['Expt ', ExptID,': MonoAcetone Glucose 13C NMR Spectrum at Turn ',num2str(TurnNumber)];
SimplePlotSpectrum(CWS, PPMR, YR, txt);
axidx = axidx + 1;

for i = 1:6
    PPM = FreqsPPM(i);
    PPMR = [PPM - (PPMW/2.0), PPM + (PPMW/2.0)];
    T = sprintf('%5.3f',FE(i));
    
    PPML = PPM - (PPMW/2.0);
    PPMH = PPM + (PPMW/2.0);
    
    PPMT = CWS.PPMTable;
    FD = CWS.FreqDomainData;
    FD = FD(PPMT >= PPML & PPMT <= PPMH);
    ReFD = real(FD);
%     S = sum(ReFD);
    
%     U = sprintf('%5.3f',S); 
    txt = ['MAG C', num2str(i),' (FE: ', T, ')'];
    axes(Axs(axidx));
    cla;
    SimplePlotSpectrum(CWS, PPMR, YR, txt);
    axidx = axidx + 1;
end

axes(Axs(axidx))
cla;
txt = ['Expt ', ExptID,': MAG Isotopomers at Turn ',num2str(TurnNumber)];
BarhPlotIsotopomerEnrichment(MAG, TurnNumber, txt, 'b');
axidx = axidx + 1;

axes(Axs(axidx))
cla;
Title = ['Expt ', ExptID,': MAG Isotopologues at Turn ',num2str(TurnNumber)];
GlcMass = Isotopomers2Isotopologues(MAG);
BarPlotMass(GlcMass, TurnNumber, Title, 'r');

end

