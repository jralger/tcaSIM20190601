function DumpOneMultipletTimeSeriesToCSV(M, MID, FN, ExptID, VersionID)

if strcmp(MID, 'Glutamate')
   Mults = BuildGluDefaultMultiplets();
end
if strcmp(MID, 'Glu')
   Mults = BuildGluDefaultMultiplets();
end

if strcmp(MID, 'Alanine')
   Mults = BuildAlaDefaultMultiplets();
end
if strcmp(MID, 'Ala')
   Mults = BuildAlaDefaultMultiplets();
end

if strcmp(MID, 'Aspartate')
   Mults = BuildAspDefaultMultiplets();
end
if strcmp(MID, 'Asp')
   Mults = BuildAspDefaultMultiplets();
end

if strcmp(MID, 'beta-Hydroxybutyrate')
   Mults = BuildbHBDefaultMultiplets();
end
if strcmp(MID, 'bHB')
   Mults = BuildbHBDefaultMultiplets();
end

if strcmp(MID, 'Glucose')
   Mults = BuildGlcDefaultMultiplets();
end

if strcmp(MID, 'Glc')
   Mults = BuildGlcDefaultMultiplets();
end

if strcmp(MID, 'MAG')
   Mults = BuildMAGDefaultMultiplets();
end

if strcmp(MID, 'MonoAcetone Glucose')
   Mults = BuildMAGDefaultMultiplets();
end



nMults = size(Mults, 2);
% IDs = cell(1, nMults);
for i = 1:nMults
    Mult = Mults(1, i);
    ID = [Mult.ID];
    IDs(1, i) = {ID};
end

nTurns = size(M,1);
CA = zeros(nTurns, nMults);
for i = 1:nTurns
    V = M(i,:);
    
    if strcmp(MID, 'Glutamate')
       Mults = SimulateGluSpectra(Mults, V);
    end
    if strcmp(MID, 'Glu')
       Mults = SimulateGluSpectra(Mults, V);
    end
    
    if strcmp(MID, 'Alanine')
       Mults = SimulateAlaSpectra(Mults, V);
    end
    if strcmp(MID, 'Ala')
       Mults = SimulateAlaSpectra(Mults, V);
    end
    
    if strcmp(MID, 'Aspartate')
       Mults = SimulateAspSpectra(Mults, V);
    end
    if strcmp(MID, 'Asp')
       Mults = SimulateAspSpectra(Mults, V);
    end
    
    if strcmp(MID, 'beta-Hydroxybutyrate')
       Mults = SimulatebHBSpectra(Mults, V);
    end
    if strcmp(MID, 'bHB')
       Mults = SimulatebHBSpectra(Mults, V);
    end
       
    if strcmp(MID, 'Glucose')
       Mults = SimulateGlcSpectra(Mults, V);
    end
    
    if strcmp(MID, 'Glc')
       Mults = SimulateGlcSpectra(Mults, V);
    end
         
    if strcmp(MID, 'MAG')
       Mults = SimulateMAGSpectra(Mults, V);
    end
         
    if strcmp(MID, 'MonoAcetone Glucose')
       Mults = SimulateMAGSpectra(Mults, V);
    end
    
    for j = 1:nMults
        Mult = Mults(j);
        CA(i,j) = Mult.RelConc;
    end
end

fileID = fopen(FN, 'w');
txt = 'tcaSIM Multiplet Simlation\n';
fprintf(fileID, txt);

WritePreambleTCAS(fileID, VersionID, ExptID);

txt = ',Relative Multiplet Conc At Turn Number\n';
fprintf(fileID, txt);

txt = 'MultipletID,';
for i=1:nTurns
    txt = [txt,num2str(i),','];
end
txt = [txt,'\n'];
fprintf(fileID, txt);

for i = 1:nMults
    ID = char(IDs(1, i));
    txt = [ID, ','];
    V = CA(:, i);
    for j = 1:nTurns
        txt = [txt, num2str(V(j)), ','];
    end
    txt = [txt, '\n'];
    fprintf(fileID, txt);
end
fclose(fileID);
end

