function varargout = InputOneCarbonIsotopomers(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @InputOneCarbonIsotopomers_OpeningFcn, ...
                   'gui_OutputFcn',  @InputOneCarbonIsotopomers_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function hObject = CheckFixNegatives(hObject)
         V = str2double(get(hObject,'String'));
         if V < 0
             hObject.String = ['0'];
         end
         
function hObject = CheckFixGTOne(hObject)
         V = str2double(get(hObject,'String'));
         if V > 1.0
             hObject.String = ['1'];
         end

function [handles, A] = DoCallBack(hObject, handles)
    hObject = CheckFixGTOne(hObject);
    hObject = CheckFixNegatives(hObject);
    [handles, A] = ReadUpdateAllOneCarbonIsotopomers(handles);
    guidata(hObject, handles);  
    
function InputOneCarbonIsotopomers_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
MolID = char(varargin(2));
A = cell2mat(varargin(3));
Z = handles.MoleculeID;
Z.String = MolID;
handles.MoleculeID = Z;

[o, x] = DefineOneCarbonLabelIndices();

handles.O.String = sprintf('%4.2f',A(1, o));
handles.X.String = sprintf('%4.2f',A(1, x));

[handles, A] = ReadUpdateAllOneCarbonIsotopomers(handles);

guidata(hObject, handles);
uiwait(handles.figure1);


function varargout = InputOneCarbonIsotopomers_OutputFcn(hObject, eventdata, handles)
[handles, A]  = ReadUpdateAllOneCarbonIsotopomers(handles);
varargout{1} = A;
close();


function pushbutton1_Callback(hObject, eventdata, handles)
uiresume;


function O_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function X_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function O_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);


function X_Callback(hObject, eventdata, handles)
[handles, A] = DoCallBack(hObject, handles);
