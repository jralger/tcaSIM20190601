function varargout = tcaSIM_Advanced(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tcaSIM_Advanced_OpeningFcn, ...
                   'gui_OutputFcn',  @tcaSIM_Advanced_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function hObject = CheckFixNegatives(hObject)
 V = str2double(get(hObject,'String'));
 if V < 0
     hObject.String = sprintf('%4.2f',0);
 end

% --- Executes just before tcaSIM_Advanced is made visible.
function tcaSIM_Advanced_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;

axes(handles.axes1);
cla;
P = imread('PathwayDiagram20180831A.png');
image(P);
axis off;

Substrates = SetDefaultSubstrates(handles.ExactNA.Value);
handles.Lac = Substrates.Lac;
handles.FA = Substrates.FA;
handles.CO2 = Substrates.CO2;
handles.Glyc = Substrates.Glyc;
handles.SuccYs = Substrates.SuccYs;
handles.Gln = Substrates.Gln;

[o, x] = DefineOneCarbonLabelIndices();
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                          DefineFourCarbonLabelIndices();
[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();

V = Substrates.Lac(1, ooo);
if V < 1.0
    handles.LacCheck.Value = 1;
end

V = Substrates.Glyc(1, ooo);
if V < 1.0
    handles.GlycCheck.Value = 1;
end

V = Substrates.CO2(1, o);
if V < 1.0
    handles.CO2Check.Value = 1;
end

V = Substrates.SuccYs(1, oooo);
if V < 1.0
    handles.SuccYsCheck.Value = 1;
end

V = Substrates.FA(1, oo);
if V < 1.0
    handles.FACheck.Value = 1;
end

V = Substrates.Gln(1, ooooo);
if V < 1.0
    handles.GlnCheck.Value = 1;
end

MetabolicModel = SetDefaultMetabolicModel();
handles.Ys.String = sprintf('%5.2f', MetabolicModel.Ys);
handles.GlnYs.String = sprintf('%5.2f', MetabolicModel.GlnYs);
handles.GK.String = sprintf('%5.2f', MetabolicModel.GK);
handles.YPC.String = sprintf('%5.2f', MetabolicModel.YPC);
handles.PDH.String = sprintf('%5.2f', MetabolicModel.PDH);
handles.PK.String = sprintf('%5.2f', MetabolicModel.PK);
handles.ROF.String = sprintf('%5.2f', MetabolicModel.ROF);
handles.RSM.String = sprintf('%5.2f', MetabolicModel.RSM);
handles.TPI.String = sprintf('%5.2f', MetabolicModel.TPI);
handles.EaKG.String = sprintf('%5.2f', MetabolicModel.EaKG);
handles.ECit.String = sprintf('%5.2f', MetabolicModel.ECit);
handles.EOAA.String = sprintf('%5.2f', MetabolicModel.EOAA);
handles.nTurns.String = sprintf('%4.0f', MetabolicModel.nTurns);
handles.ExactNA.Value = MetabolicModel.ExactNaturalAbundance;
handles.ExptID.String = MetabolicModel.ExptID;

axes(handles.axes2);
cla;
n = 1;
txt = ['Expt ', handles.ExptID.String,': aKG at Turn ',num2str(n)];
if handles.ExactNA.Value
    NA = Define13CNaturalAbundance();
    aKG = BuildFiveCarbonNaturalAbundance(NA);
else
    aKG = zeros(1,32);
    aKG = UpdateUnLabelledIsotopomer(aKG);
end
BarhPlotIsotopomerEnrichment(aKG, n, txt, 'b');

handles.output = hObject;
guidata(hObject, handles);


% UIWAIT makes tcaSIM_Advanced wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tcaSIM_Advanced_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%% All CreateFcns %%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Ys_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function GK_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function YPC_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PDH_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PK_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ROF_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function RSM_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function TPI_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function EaKG_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ECit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function EOAA_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function nTurns_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function axes1_CreateFcn(hObject, eventdata, handles)

function GlnYs_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ExptID_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SkipGlu_CreateFcn(hObject, eventdata, handles)

function RunCSV_CreateFcn(hObject, eventdata, handles)


%%%%%%%%%%%%%%%%%  End All CreateFCNs %%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%  All Callbacks %%%%%%%%%%%%%%%%%%%%%%%%%
function LacCheck_Callback(hObject, eventdata, handles)
Lac = handles.Lac;
MolID = 'Lactate';
Lac = InputThreeCarbonIsotopomers('InputLac', MolID, Lac);
handles.Lac = Lac;
Z = handles.LacCheck;
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
if Lac(1,ooo) ~= 1.0
    Z.Value = 1;
    handles.LacCheck = Z;
end
if Lac(1,ooo) == 1.0
    Z.Value = 0;
    handles.LacCheck = Z;
end
guidata(hObject, handles);

function GlycCheck_Callback(hObject, eventdata, handles)
Glyc = handles.Glyc;
MolID = 'Glycerol';
Glyc = InputThreeCarbonIsotopomers('InputGlyc', MolID, Glyc);
handles.Glyc = Glyc;
Z = handles.GlycCheck;
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
if Glyc(1,ooo) ~= 1.0
    Z.Value = 1;
    handles.GlycCheck = Z;
end
if Glyc(1,ooo) == 1.0
    Z.Value = 0;
    handles.GlycCheck = Z;
end
guidata(hObject, handles);

function FACheck_Callback(hObject, eventdata, handles)
FA = handles.FA;
MolID = 'Acetate (Fatty Acid Equivalent)';
FA = InputTwoCarbonIsotopomers('InputFA', MolID, FA);
handles.FA = FA;
Z = handles.FACheck;
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
if FA(1,oo) ~= 1.0
    Z.Value = 1;
    handles.FACheck = Z;
end
if FA(1,oo) == 1.0
    Z.Value = 0;
    handles.FACheck = Z;
end
guidata(hObject, handles);

function SuccYsCheck_Callback(hObject, eventdata, handles)
SuccYs = handles.SuccYs;
MolID = 'SuccYs';
SuccYs = InputFourCarbonIsotopomers('InputSuccYs', MolID, SuccYs);
handles.SuccYs = SuccYs;
Z = handles.SuccYsCheck;
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                     DefineFourCarbonLabelIndices();
if SuccYs(1,oooo) ~= 1.0
    Z.Value = 1;
    handles.SuccYsCheck = Z;
end
if SuccYs(1,oooo) == 1.0
    Z.Value = 0;
    handles.SuccYsCheck = Z;
end
guidata(hObject, handles);

function CO2Check_Callback(hObject, eventdata, handles)
CO2 = handles.CO2;
MolID = 'CO2 (Bicarbonate)';
CO2 = InputOneCarbonIsotopomers('InputCO2', MolID, CO2);
handles.CO2 = CO2;
Z = handles.CO2Check;
[o, x] = DefineOneCarbonLabelIndices();
if CO2(1,o) ~= 1.0
    Z.Value = 1;
    handles.CO2Check = Z;
end
if CO2(1,o) == 1.0
    Z.Value = 0;
    handles.CO2Check = Z;
end
guidata(hObject, handles);

function Ys_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
Ys = str2double(get(hObject,'String'));
hObject.String = sprintf('%5.2f',Ys);
guidata(hObject, handles);

function GK_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
GK = str2double(get(hObject,'String'));
hObject.String = sprintf('%5.2f',GK);
guidata(hObject, handles);

function YPC_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
YPC = str2double(get(hObject,'String'));
hObject.String = sprintf('%5.2f',YPC);
guidata(hObject, handles);

function PDH_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
PDH = str2double(get(hObject,'String'));
hObject.String = sprintf('%4.2f',PDH);
if PDH > 1
    hObject.String = sprintf('%4.2f',1.0);
end
guidata(hObject, handles);

function PK_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
PK = str2double(get(hObject,'String'));
hObject.String = sprintf('%5.2f',PK);
guidata(hObject, handles);

function ROF_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
ROF = str2double(get(hObject,'String'));
hObject.String = sprintf('%4.2f',ROF);
if ROF > 1
    hObject.String = sprintf('%4.2f',1.0);
end
guidata(hObject, handles);

function RSM_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
RSM = str2double(get(hObject,'String'));
hObject.String = sprintf('%4.2f',RSM);
if RSM > 1
    hObject.String = sprintf('%4.2f',1.0);
end
guidata(hObject, handles);

function TPI_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
TPI = str2double(get(hObject,'String'));
hObject.String = sprintf('%4.2f',TPI);
if TPI > 1
    hObject.String = sprintf('%4.2f',1.0);
end
guidata(hObject, handles);

function Done_Callback(hObject, eventdata, handles)
close;

function CheckSkipAnimation_Callback(hObject, eventdata, handles)

function EaKG_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
EaKG = str2double(get(hObject,'String'));
hObject.String = sprintf('%5.2f',EaKG);
guidata(hObject, handles);

function ECit_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
ECit = str2double(get(hObject,'String'));
hObject.String = sprintf('%5.2f',ECit);
guidata(hObject, handles);

function EOAA_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
EOAA = str2double(get(hObject,'String'));
hObject.String = sprintf('%5.2f',EOAA);
guidata(hObject, handles);

function nTurns_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
if V < 1
    hObject.String = ['1'];
end
nTurns = str2double(get(hObject,'String'));
hObject.String = sprintf('%4.0f',nTurns);
guidata(hObject, handles);

function SkipMAG_Callback(hObject, eventdata, handles)

function SkipAlanine_Callback(hObject, eventdata, handles)

function SkipbHB_Callback(hObject, eventdata, handles)

function SkipAspartate_Callback(hObject, eventdata, handles)

function SkipMoleculeDiagrams_Callback(hObject, eventdata, handles)

function Skip13CStackedPlots_Callback(hObject, eventdata, handles)

function GlnYs_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
GlnYs = str2double(get(hObject,'String'));
hObject.String = sprintf('%5.2f',GlnYs);
guidata(hObject, handles);

function ExactNA_Callback(hObject, eventdata, handles)
axes(handles.axes2);
cla;
n = 1;
txt = ['Expt ', handles.ExptID.String,': aKG at Turn ',num2str(n)];
if handles.ExactNA.Value
    NA = Define13CNaturalAbundance();
    aKG = BuildFiveCarbonNaturalAbundance(NA);
else
    aKG = zeros(1,32);
    aKG = UpdateUnLabelledIsotopomer(aKG);
end
BarhPlotIsotopomerEnrichment(aKG, n, txt, 'b');

Substrates = SetDefaultSubstrates(handles.ExactNA.Value);
handles.Lac = Substrates.Lac;
handles.FA = Substrates.FA;
handles.CO2 = Substrates.CO2;
handles.Glyc = Substrates.Glyc;
handles.SuccYs = Substrates.SuccYs;
handles.Gln = Substrates.Gln;

[o, x] = DefineOneCarbonLabelIndices();
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                          DefineFourCarbonLabelIndices();
[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();

handles.LacCheck.Value = 0;
handles.GlycCheck.Value = 0;
handles.CO2Check.Value = 0;
handles.SuccYsCheck.Value = 0;
handles.FACheck.Value = 0;
handles.GlnCheck.Value = 0;
if Substrates.Lac(1, ooo) < 1.0
    handles.LacCheck.Value = 1;
end
if Substrates.Glyc(1, ooo) < 1.0
    handles.GlycCheck.Value = 1;
end
if Substrates.CO2(1, o) < 1.0
    handles.CO2Check.Value = 1;
end
if Substrates.SuccYs(1, oooo) < 1.0
    handles.SuccYsCheck.Value = 1;
end
if Substrates.FA(1, oo) < 1.0
    handles.FACheck.Value = 1;
end
if Substrates.Gln(1, ooooo) < 1.0
    handles.GlnCheck.Value = 1;
end

guidata(hObject, handles);



function ExptID_Callback(hObject, eventdata, handles)

% --- Executes on button press in GlnCheck.
function GlnCheck_Callback(hObject, eventdata, handles)
Gln = handles.Gln;
MolID = 'Glutamine';
Gln = InputFiveCarbonIsotopomers('InputGln', MolID, Gln);
handles.Gln = Gln;
Z = handles.GlnCheck;
[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();
if Gln(1,ooooo) ~= 1.0
    Z.Value = 1;
    handles.GlnCheck = Z;
end
if Gln(1,ooooo) == 1.0
    Z.Value = 0;
    handles.GlnCheck = Z;
end
guidata(hObject, handles);

function SkipGlu_Callback(hObject, eventdata, handles)

function RunGUI_Callback(hObject, eventdata, handles)
NoInputTest = 0;
LDHFailTest = 0;

MetabolicModel = SetDefaultMetabolicModel;
MetabolicModel.ExptID = handles.ExptID.String;
MetabolicModel.GK = str2double(handles.GK.String);
MetabolicModel.GlnYs = str2double(handles.GlnYs.String);
MetabolicModel.Ys = str2double(handles.Ys.String);
MetabolicModel.YPC = str2double(handles.YPC.String);
MetabolicModel.PDH = str2double(handles.PDH.String);
MetabolicModel.PK = str2double(handles.PK.String);
MetabolicModel.ROF = str2double(handles.ROF.String);
MetabolicModel.RSM = str2double(handles.RSM.String);
MetabolicModel.TPI = str2double(handles.TPI.String);
MetabolicModel.EaKG = str2double(handles.EaKG.String);
MetabolicModel.ECit = str2double(handles.ECit.String);
MetabolicModel.EOAA = str2double(handles.EOAA.String);
MetabolicModel.nTurns = str2double(handles.nTurns.String);
MetabolicModel.ExactNaturalAbundance = handles.ExactNA.Value;

Substrates = SetDefaultSubstrates(handles.ExactNA.Value);
Substrates.Lac = handles.Lac;
Substrates.FA = handles.FA;
Substrates.Gln = handles.Gln;
Substrates.CO2 = handles.CO2;
Substrates.Glyc = handles.Glyc;
Substrates.SuccYs = handles.SuccYs;
Substrates.Gln = handles.Gln;

SkipOutput = SetDefaultSkipOutput();
SkipOutput.MultStackedPlots = handles.Skip13CStackedPlots.Value;
SkipOutput.MolLabelDiagram = handles.SkipMoleculeDiagrams.Value;
SkipOutput.Asp = handles.SkipAspartate.Value;
SkipOutput.bHB = handles.SkipbHB.Value;
SkipOutput.Ala = handles.SkipAlanine.Value;
SkipOutput.MAG = handles.SkipMAG.Value;
SkipOutput.Glu = handles.SkipGlu.Value;
SkipOutput.SkipAnimation = handles.CheckSkipAnimation.Value;



if NoInputTest == 1
    NoInputODN = 'C:\Users\Jeffry R Alger\Desktop\tcaSIMtest';
    
    Lac = zeros(1,8);
    [ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                        DefineThreeCarbonLabelIndices();
    Lac(1, xxx) = 0.65;
    Lac = UpdateUnLabelledIsotopomer(Lac);
    Substrates.Lac = Lac;
    
    FA = zeros(1,4);
    [oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
    FA(1, ox) = 0.35;
    FA(1, xo) = 0.37;
    FA(1, xx) = 1- sum(FA) - 0.03;
    FA = UpdateUnLabelledIsotopomer(FA);
    Substrates.FA = FA;

    Gln = zeros(1,32);
    [ooooo, xoooo, oxooo, xxooo, ...
     ooxoo, xoxoo, oxxoo, xxxoo, ...
     oooxo, xooxo, oxoxo, xxoxo, ...
     ooxxo, xoxxo, oxxxo, xxxxo, ...
     oooox, xooox, oxoox, xxoox, ...
     ooxox, xoxox, oxxox, xxxox, ...
     oooxx, xooxx, oxoxx, xxoxx, ...
     ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();    
    Gln(1, xxxxx) = 0.95;
    Gln = UpdateUnLabelledIsotopomer(Gln);
    Substrates.Gln = Gln;

    MetabolicModel.ExptID = 'TestOutput';
    MetabolicModel.ExactNaturalAbundance = 1;
    
    ODN = NoInputODN;
end

if LDHFailTest
    S = MetabolicModel.YPC + MetabolicModel.PDH;
    MetabolicModel.PK = S + 1;
end
    
LDH = MetabolicModel.YPC + MetabolicModel.PDH - MetabolicModel.PK;
if LDH < 0
    FailLDHMsgBox();
else 
    if NoInputTest == 0
        txt = 'Browse to tcaSIM Output Folder.';
        SP = cd;
        ODN = uigetdir(SP, txt);
        Q = strcmp(SP, ODN);
        while Q
            txt = 'Output folder can not be the source code folder.  Browse to a legal tcaSIM Output Folder.' ;
            ODN = uigetdir(SP, txt);
            Q = strcmp(SP, ODN);
        end
    end
    RuntcaSIM(ODN, Substrates, MetabolicModel, handles.axes2, SkipOutput);
    SuccessMsgBox();
end


function RunCSV_Callback(hObject, eventdata, handles)

% ODN = 'C:\Users\Jeffry R Alger\Desktop\CMTestSims20190524\tcaSIMEval20190524CSV\';
% FN = 'C:\Users\Jeffry R Alger\Desktop\CMTestSims20190524\tcaSIMEval20190524CSV\tcaSIMInput19CMSims.csv';
NoInputTest = 0;

if NoInputTest == 0    
    SP = cd;
    SP = [SP, '\'];
    txt = 'Browse to tcaSIM Input .CSV';
    [BN, ODN] = uigetfile('*.csv',txt);
    Q = strcmp(SP, ODN);
    while Q
        txt = 'Output folder can not be the source code folder.  Browse to a legal tcaSIM Input .CSV' ;
        [BN, ODN] = uigetfile('*.csv',txt);
        Q = strcmp(SP, ODN);
    end
    FN = [ODN, BN];
end

if NoInputTest == 1    
    ODN = 'C:\Users\Jeffry R Alger\Desktop\ErrTests\';
    BN = 'tcaSIMInputErrors.csv';
    FN = [ODN, BN];
end

[o, x] = DefineOneCarbonLabelIndices();

[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();

[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
                                
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                          DefineFourCarbonLabelIndices();
                                      
[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();

NA = Define13CNaturalAbundance();

[MetabolicModels, SubstatesArray, SkipOutputs] = ReadtcaSIMInputCSV(FN);

[MetabolicModels, SubstatesArray, SkipOutputs, nExpts] = ...
              CheckForIllegalCSVInput(MetabolicModels, SubstatesArray, ...
                                      SkipOutputs, ODN, BN);

for i = 1:nExpts
    MetabolicModel = MetabolicModels(1, i);
    Substrates = SubstatesArray(1, i);
    SkipOutput = SkipOutputs(1, i);
    
    handles.Ys.String = sprintf('%5.2f', MetabolicModel.Ys);
    handles.GlnYs.String = sprintf('%5.2f', MetabolicModel.GlnYs);
    handles.GK.String = sprintf('%5.2f', MetabolicModel.GK);
    handles.YPC.String = sprintf('%5.2f', MetabolicModel.YPC);
    handles.PDH.String = sprintf('%5.2f', MetabolicModel.PDH);
    handles.PK.String = sprintf('%5.2f', MetabolicModel.PK);
    handles.ROF.String = sprintf('%5.2f', MetabolicModel.ROF);
    handles.RSM.String = sprintf('%5.2f', MetabolicModel.RSM);
    handles.TPI.String = sprintf('%5.2f', MetabolicModel.TPI);
    handles.EaKG.String = sprintf('%5.2f', MetabolicModel.EaKG);
    handles.ECit.String = sprintf('%5.2f', MetabolicModel.ECit);
    handles.EOAA.String = sprintf('%5.2f', MetabolicModel.EOAA);
    handles.nTurns.String = sprintf('%4.0f', MetabolicModel.nTurns);
    handles.ExactNA.Value = MetabolicModel.ExactNaturalAbundance;
    handles.ExptID.String = MetabolicModel.ExptID; 
    
    if MetabolicModel.ExactNaturalAbundance
        if Substrates.Lac(1, ooo) == 1
            Substrates.Lac = BuildThreeCarbonNaturalAbundance(NA);
        end
        if Substrates.FA(1, oo) == 1
            Substrates.FA = BuildTwoCarbonNaturalAbundance(NA);
        end
        if Substrates.Gln(1, ooooo) == 1
            Substrates.Gln = BuildFiveCarbonNaturalAbundance(NA);
        end
        if Substrates.CO2(1, o) == 1
            Substrates.CO2 = BuildOneCarbonNaturalAbundance(NA);
        end
        if Substrates.Glyc(1, ooo) == 1
            Substrates.Glyc = BuildThreeCarbonNaturalAbundance(NA);
        end
        if Substrates.SuccYs(1, oooo) == 1
            Substrates.SuccYs = BuildFourCarbonNaturalAbundance(NA);
        end
    end
    
    handles.LacCheck.Value = 0;
    handles.GlycCheck.Value = 0;
    handles.CO2Check.Value = 0;
    handles.SuccYsCheck.Value = 0;
    handles.FACheck.Value = 0;
    handles.GlnCheck.Value = 0;
    if Substrates.Lac(1, ooo) < 1.0
        handles.LacCheck.Value = 1;
    end
    if Substrates.Glyc(1, ooo) < 1.0
        handles.GlycCheck.Value = 1;
    end
    if Substrates.CO2(1, o) < 1.0
        handles.CO2Check.Value = 1;
    end
    if Substrates.SuccYs(1, oooo) < 1.0
        handles.SuccYsCheck.Value = 1;
    end
    if Substrates.FA(1, oo) < 1.0
        handles.FACheck.Value = 1;
    end
    if Substrates.Gln(1, ooooo) < 1.0
        handles.GlnCheck.Value = 1;
    end

    handles.Lac = Substrates.Lac;
    handles.FA = Substrates.FA;
    handles.Gln = Substrates.Gln;
    handles.Glyc = Substrates.Glyc;
    handles.SuccYs = Substrates.SuccYs;
    handles.Gln = Substrates.Gln;
    
    axes(handles.axes2);
    cla;
    n = 1;
    txt = ['Expt ', MetabolicModel.ExptID,': aKG at Turn ',num2str(n)];
    if MetabolicModel.ExactNaturalAbundance
        aKG = BuildFiveCarbonNaturalAbundance(NA);
    else
        aKG = zeros(1,32);
        aKG = UpdateUnLabelledIsotopomer(aKG);
    end
    BarhPlotIsotopomerEnrichment(aKG, n, txt, 'b');
    
    handles.Skip13CStackedPlots.Value = SkipOutput.MultStackedPlots;
    handles.SkipMoleculeDiagrams.Value = SkipOutput.MolLabelDiagram;
    handles.SkipAspartate.Value = SkipOutput.Asp;
    handles.SkipbHB.Value = SkipOutput.bHB;
    handles.SkipAlanine.Value = SkipOutput.Ala;
    handles.SkipMAG.Value = SkipOutput.MAG;
    handles.SkipGlu.Value = SkipOutput.Glu;
    handles.CheckSkipAnimation.Value = SkipOutput.SkipAnimation;
    
    LDH = MetabolicModel.YPC + MetabolicModel.PDH - MetabolicModel.PK;
    if LDH < 0
        FailLDHMsgBox();
    else  
        RuntcaSIM(ODN, Substrates, MetabolicModel, handles.axes2, SkipOutput);
    end

end
SuccessMsgBox();

