function R = DisplaySaveStackedMultipletSpectra(BMPDN, Multiplets)
Ls = {'r-', 'b-', 'g-', 'c-', 'm-'};
PPMR = 2.0;

T = strsplit(BMPDN, '\');
nT = size(T,2);
T = char(T(nT));
T = strsplit(T, '_');
ExptID = char(T(1));

SMults = transpose(Multiplets);
uIDs = GetUniqueCarbonIDs(SMults);
nIDs = size(uIDs,2);
for i = 1:nIDs
    uID = uIDs(i);
    RMults = IsolateMoleculesByCarbonID(SMults, uID);
    nRM = size(RMults, 1);
    SConc = 0.0;
    for j = 1:nRM
        T = RMults(j);
        SConc = SConc + T.Conc;
        PlotCenter = T.FreqPPM;
        PPML = PlotCenter - (0.5*PPMR);
        PPMH = PlotCenter + (0.5*PPMR);
        CWS = T.ConcWtdSpectrum;
        PPMT = CWS.PPMTable;
        TFD = CWS.FreqDomainData;
        reTFD = real(TFD);
        TY = reTFD(PPMT >= PPML & PPMT <= PPMH);
        X = PPMT(PPMT >= PPML & PPMT <= PPMH);
        if j == 1
            Y = TY;
        end
        if j > 1
            Y = Y + TY;
        end
    end
    maxY = max(Y);
    scrsz = get(groot,'ScreenSize');
    figure('Name', char(uID), ...
           'Position', [1 4*scrsz(2)/8 4*scrsz(3)/8 4*scrsz(4)/8], ...
           'Color', 'white');
    hold on
    Plots = [];
    T = sprintf('%5.3f',SConc);
    S = sum(Y);
    U = sprintf('%5.3f',S);     
    txt = [char(uID), ' Sum                                    AbsConc: ', T]; 
%     txt = [char(uID), ' Sum                                    AbsConc: ', T, '   AUC: ', U];  
%     txt = [char(uID), ' Sum'];
    Plots(1) = plot(X, Y, char(Ls(1)), 'linewidth', 2.0, 'DisplayName', txt);
    for j = 1:nRM
        T = RMults(j);
        PlotCenter = T.FreqPPM;
        PPML = PlotCenter - (0.5*PPMR);
        PPMH = PlotCenter + (0.5*PPMR);
        CWS = T.ConcWtdSpectrum;
        PPMT = CWS.PPMTable;
        TFD = CWS.FreqDomainData;
        reTFD = real(TFD);
        S = sum(reTFD);
        TY = reTFD(PPMT >= PPML & PPMT <= PPMH);
        X = PPMT(PPMT >= PPML & PPMT <= PPMH);
        Y = TY + (1.1*maxY);
        Z = Y;
        Z(:) = (1.1*maxY);
        plot(X,Z, 'k--', 'linewidth', 0.5);
        Q = sprintf('%5.3f',T.Conc);
        RQ = sprintf('%5.3f',T.RelConc);
        U = sprintf('%5.3f',S);
        nID = size(T.ID,2);
        P = '  ';
        if nID == 8
            P = '      ';
        end
        DNT = [T.ID, P, '    FracConc: ', RQ, '    AbsConc: ', Q];
%         DNT = [T.ID, P, '    FracConc: ', RQ, '    AbsConc: ', Q, '    AUC: ', U];
        Plots(1+j) = plot(X, Y, char(Ls(1+j)), 'linewidth', 2.0, 'DisplayName', DNT);
        maxY = max(Y);
    end

    if maxY == 0.0
        maxY = 0.0000001;
    end
    maxPY = 1.1*maxY;
    minPY = 0.0;
    axis([PPML, PPMH, minPY, maxPY]);
    box off;
    ax = gca;
    ax.XDir = 'reverse';
    xtickformat('%,.1f');
    ax.TickDir = 'out';
    xlabel('PPM', 'FontSize', 9);
    ax.YAxis.Visible = 'off';
%     ax.XAxis.Visible = 'off';
    legend(Plots,'Location','eastoutside');
    uID = char(uID);
    U = strsplit(uID, ' ');
    A = char(U(1));
    B = char(U(2));
    if strcmp(A,'Glu')
        A = 'Glutamate';
    end
    if strcmp(A,'Lac')
        A = 'Lactate';
    end
    if strcmp(A,'bHB')
        A = 'beta-Hydroxybutyrate';
    end
    if strcmp(A,'Ala')
        A = 'Alanine';
    end
    if strcmp(A,'Asp')
        A = 'Aspartate';
    end
    if strcmp(A,'Glc')
        A = 'Glucose';
    end
    if strcmp(A,'MAG')
        A = 'MonoAcetone Glucose';
    end
    U = [A, ' ', B];
    txt = ['Expt ', ExptID, ': ', U, ' Multiplets on Final TCA Cycle Turn'];
    title(txt);
    idx = strfind(uID,' ');
    uID(idx) = '_';
    FN = [BMPDN, '_', uID, '_Multiplets_FinalTurn.png'];
    saveas(gcf,FN);
    pause(1);
    hold off;
    close;
end


R = 1;
end
        




