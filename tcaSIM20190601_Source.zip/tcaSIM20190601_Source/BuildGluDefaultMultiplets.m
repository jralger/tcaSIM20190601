function Multiplets = BuildGluDefaultMultiplets()

GlobalR2 = SetDefaultR2();

R = SetDefaultChemicalShifts();
GluFreqsPPM = R.GluEstFreqsPPM;

R = SetDefaultJs();
GluJAHz = R.GluEstJAHz;

% R = SetDefaultIsotopeShifts();

Spectrum = BuildDefaultSpectrum();

ID = 'Glu C1 S';
FreqPPM = GluFreqsPPM(1);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);

Multiplets = [Multiplet, ...  %1: Glu C1 S
              Multiplet, ...  %2: Glu C1 D
              Multiplet, ...  %3: Glu C2 S
              Multiplet, ...  %4: Glu C2 D12
              Multiplet, ...  %5: Glu C2 D23
              Multiplet, ...  %6: Glu C2 Q
              Multiplet, ...  %7: Glu C3 S
              Multiplet, ...  %8: Glu C3 D
              Multiplet, ...  %9: Glu C3 T
              Multiplet, ...  %10: Glu C4 S
              Multiplet, ...  %11: Glu C4 D34
              Multiplet, ...  %12: Glu C4 D45
              Multiplet, ...  %13: Glu C4 Q
              Multiplet, ...  %14: Glu C5 S
              Multiplet];      %15: Glu C5 D
n = 2;

ID = 'Glu C1 D';
FreqPPM = GluFreqsPPM(1);
JHz = GluJAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C2 S';
FreqPPM = GluFreqsPPM(2);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C2 D12';
FreqPPM = GluFreqsPPM(2);
JHz = GluJAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C2 D23';
FreqPPM = GluFreqsPPM(2);
JHz = GluJAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C2 Q';
FreqPPM = GluFreqsPPM(2);
JHz = [GluJAHz(1,2), GluJAHz(2,3)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C3 S';
FreqPPM = GluFreqsPPM(3);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C3 D'; %assumes Glu C3 D23 and Glu C3 D34 are not distinguishable
FreqPPM = GluFreqsPPM(3);
JHz = GluJAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C3 T';
FreqPPM = GluFreqsPPM(3);
JHz = [GluJAHz(2,3), GluJAHz(3,4)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C4 S';
FreqPPM = GluFreqsPPM(4);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C4 D34';
FreqPPM = GluFreqsPPM(4);
JHz = GluJAHz(3,4);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C4 D45';
FreqPPM = GluFreqsPPM(4);
JHz = GluJAHz(4,5);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C4 Q';
FreqPPM = GluFreqsPPM(4);
JHz = [GluJAHz(4,5), GluJAHz(3,4)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C5 S';
FreqPPM = GluFreqsPPM(5);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'Glu C5 D';
FreqPPM = GluFreqsPPM(5);
JHz = GluJAHz(4,5);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;

end

