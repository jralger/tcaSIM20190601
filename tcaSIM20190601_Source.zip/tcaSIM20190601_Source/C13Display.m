function C13Display(MolID, Mol, ExptID, ODN)

if strcmp(MolID, 'Glu')
    GluC13Display(Mol, ExptID, ODN);
end

if strcmp(MolID, 'Asp')
    AspC13Display(Mol, ExptID, ODN);
end

if strcmp(MolID, 'bHB')
    bHBC13Display(Mol, ExptID, ODN);
end

if strcmp(MolID, 'Ala')
    AlaC13Display(Mol, ExptID, ODN);
end

if strcmp(MolID, 'Glc')
    GlcC13Display(Mol, ExptID, ODN);
end

if strcmp(MolID, 'MAG')
    MAGC13Display(Mol, ExptID, ODN);
end

end

