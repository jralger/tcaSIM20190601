function Molecules = SimulateAlaSpectra(Molecules, V)

[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();

nMols = size(Molecules, 2);
Mol = Molecules(1, 1);

FE = GetFractionalEnrichment(V);

for i = 1:nMols
    Mol = Molecules(1, i);
    ID = Mol.ID;
    
    if strcmp(ID, 'Ala C1 S')
      Conc = V(xoo) + V(xox);
      Mol.Conc = Conc;
      TotConc = FE(1);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Ala C1 D')
      Conc = V(xxo) + V(xxx);
      Mol.Conc = Conc;
      TotConc = FE(1);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Ala C2 S')
      Conc = V(oxo);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Ala C2 D12')
      Conc = V(xxo);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Ala C2 D23')
      Conc =  V(oxx);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Ala C2 Q')
      Conc = V(xxx);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Ala C3 S')
      Conc = V(oox) + V(xox);
      Mol.Conc = Conc;
      TotConc = FE(3);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Ala C3 D')
      Conc = V(oxx) + V(xxx);
      Mol.Conc = Conc;
      TotConc = FE(3);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
end

for i = 1:nMols
    Mol = Molecules(1, i);
    ID = Mol.ID;
    if contains(ID, 'Ala')
        NS = Mol.NormSpectrum;
        FD = NS.FreqDomainData;
        Conc = Mol.Conc;
        FD = FD*Conc;
        CWS = Mol.ConcWtdSpectrum;
        CWS.FreqDomainData = FD;
        Mol.ConcWtdSpectrum = CWS;
        Molecules(1, i) = Mol;
    end
end

% for i = 1:nMols
%     Mol = Molecules(1, i);
%     Conc = Mol.Conc
% end

end

