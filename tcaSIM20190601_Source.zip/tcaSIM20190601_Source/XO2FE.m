function FE = XO2FE(XO)
nchar = size(XO, 2);
FE = zeros(1,nchar);
for j = 1:nchar
    T = XO(1,j);
    if strcmp(T,'x')
        FE(1,j) = 1.0;
    end
end

end

