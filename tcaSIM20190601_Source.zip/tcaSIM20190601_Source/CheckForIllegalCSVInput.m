function [RMMs, RSBs, RSOs, nExpts] = CheckForIllegalCSVInput(MetabolicModels, ...
                                                      SubstatesArray, ...
                                                      SkipOutputs, ODN, BN)
FN = [ODN, 'CSVInputErrors.txt'];
fileID = fopen(FN, 'w');   
txt = ['Input Errors in ', BN, '\n'];
fprintf(fileID, txt);                                                  
                                                  
[o, x] = DefineOneCarbonLabelIndices();

[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();

[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
                                
[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                          DefineFourCarbonLabelIndices();
                                      
[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices(); 
 
nExpts = size(MetabolicModels, 2);
n = 1;
q = 0;
for i = 1:nExpts
    txt = 'Null';
    MM = MetabolicModels(1, i);
    Sb = SubstatesArray(1, i);
    SO = SkipOutputs(1, i);
    if MM.Ys < 0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (Ys < 0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.GlnYs < 0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (GlnYs < 0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.GK < 0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (GK < 0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.YPC < 0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (YPC < 0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.PDH < 0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (PDH < 0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.PDH > 1.0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (PDH > 1.0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.PK < 0.0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (PK < 0.0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.ROF < 0.0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (ROF < 0.0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.ROF > 1.0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (ROF > 1.0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.RSM < 0.0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (RSM < 0.0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.RSM > 1.0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (RSM > 1.0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.TPI < 0.0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (TPI < 0.0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.TPI > 1.0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (TPI > 1.0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.EaKG < 0.0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (EaKG < 0.0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.ECit < 0.0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (ECit < 0.0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.EOAA < 0.0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (EOAA < 0.0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.nTurns < 1.0
        txt = ['Expt: ', MM.ExptID, ' will not be run. (nTurns < 1.0).\n' ];
%         disp(txt);
        fprintf(fileID, txt);
        q = q + 1;
    end
    if MM.ExactNaturalAbundance ~= 0
        if MM.ExactNaturalAbundance ~= 1
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal UseExactNaturalAbundance).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
        end
    end
    if any(Sb.Lac(1, :) < 0)
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal Lactate C13 Enrichment).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
    end
    if any(Sb.Lac(1, :) > 1.0)
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal Lactate C13 Enrichment).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
    end
    if any(Sb.CO2(1, :) < 0)
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal CO2 C13 Enrichment).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
    end
    if any(Sb.CO2(1, :) > 1.0)
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal CO2 C13 Enrichment).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
    end
    if any(Sb.FA(1, :) < 0)
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal FA C13 Enrichment).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
    end
    if any(Sb.FA(1, :) > 1.0)
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal FA C13 Enrichment).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
    end
    if any(Sb.Gln(1, :) < 0)
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal Gln C13 Enrichment).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
    end
    if any(Sb.Gln(1, :) > 1.0)
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal Gln C13 Enrichment).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
    end
    if any(Sb.SuccYs(1, :) < 0)
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal SuccYs C13 Enrichment).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
    end
    if any(Sb.SuccYs(1, :) > 1.0)
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal SuccYs C13 Enrichment).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
    end
    if any(Sb.Glyc(1, :) < 0)
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal Glyc C13 Enrichment).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
    end
    if any(Sb.Glyc(1, :) > 1.0)
           txt = ['Expt: ', MM.ExptID, ' will not be run. (Illegal Glyc C13 Enrichment).\n' ];
%            disp(txt);
           fprintf(fileID, txt);
           q = q + 1;
    end
    LDH = MM.YPC + MM.PDH - MM.PK;
    if LDH < 0
       txt = ['Expt: ', MM.ExptID, ' will not be run. (LDH = YPC + PDH - PK  < 0).\n' ];
%        disp(txt);
       fprintf(fileID, txt);
       q = q + 1;
    end
    
    if strcmp(txt, 'Null')
        RMMs(1, n) = MM;
        RSBs(1, n) = Sb;
        RSOs(1, n) = SO;
        n = n + 1;
    end
end
nExpts = n - 1;
if nExpts == 0;
    RMMs = MetabolicModels;
    RSBs = SubstatesArray;
    RSOs = SkipOutputs;
end
if q == 0
    txt = 'No Errors. \n';
    fprintf(fileID, txt);
end

fclose(fileID);
