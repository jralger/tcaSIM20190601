function R = SetDefaultJs()
%Sets default values of J coupling constants in Hz

% updated chem shift and J info for Lac (all carbons) and Glu
% (all carbons) done 14 Aug 2017 (average of 6 high quality Agilent
% spectra after full hand picking and full fitting
% J values taken from doublets (not quartets)
% estimated values are values for the multiplets singlets (center
% line)

%Lac J Values
JAHz = zeros(3);
JAHz(1,2) = 54.63532;
JAHz(2,3) = 36.84978;
JAHz(2,1) = JAHz(1,2);
JAHz(3,2) = JAHz(2,3);
LacEstJAHz = JAHz;

%Glu J values
JAHz = zeros(5);
JAHz(1,2) = 53.49138;
JAHz(2,3) = 34.6026;
JAHz(3,4) = 34.622;
JAHz(4,5) = 51.33608;
JAHz(2,1) = JAHz(1,2);
JAHz(3,2) = JAHz(2,3);
JAHz(4,3) = JAHz(3,4);
JAHz(5,4) = JAHz(4,5);
GluEstJAHz = JAHz;

%Asp J values
JAHz = zeros(4);
JAHz(1,2) = 53.74498;
JAHz(2,3) = 36.6668;
JAHz(3,4) = 50.57935; %Check this value
% JAHz(3,4) = 48.3975; too small
JAHz(2,1) = JAHz(1,2);
JAHz(3,2) = JAHz(2,3);
JAHz(4,3) = JAHz(3,4);
AspEstJAHz = JAHz;

%bHB J values
JAHz = zeros(4);
JAHz(1,2) = 53.68585;
JAHz(2,3) = 36.6403;
JAHz(3,4) = 36.73317; % check this value
JAHz(2,1) = JAHz(1,2);
JAHz(3,2) = JAHz(2,3);
JAHz(4,3) = JAHz(3,4);
bHBEstJAHz = JAHz;


% Glc J values (needs optimization 19 Aug 2018
JAHz = zeros(6);
JAHz(1,2) = 53.0;
JAHz(2,3) = 36.0;
JAHz(3,4) = 36.0;
JAHz(4,5) = 36.0;
JAHz(5,6) = 53.0;
JAHz(2,1) = JAHz(1,2);
JAHz(3,2) = JAHz(2,3);
JAHz(4,3) = JAHz(3,4);
JAHz(5,4) = JAHz(4,5);
JAHz(6,5) = JAHz(5,6);
GlcEstJAHz = JAHz;

% MAG J values (needs optimization 30 Aug 2018)
JAHz = zeros(6);
JAHz(1,2) = 33.7;
JAHz(2,3) = 43.5;
JAHz(3,4) = 37.2;
JAHz(4,5) = 46.2;
JAHz(5,6) = 40.6;
JAHz(2,1) = JAHz(1,2);
JAHz(3,2) = JAHz(2,3);
JAHz(4,3) = JAHz(3,4);
JAHz(5,4) = JAHz(4,5);
JAHz(6,5) = JAHz(5,6);
MAGEstJAHz = JAHz;


R.AlaEstJAHz = LacEstJAHz;
R.LacEstJAHz = LacEstJAHz;
R.GluEstJAHz = GluEstJAHz;
R.AspEstJAHz = AspEstJAHz;
R.bHBEstJAHz = bHBEstJAHz;
R.GlcEstJAHz = GlcEstJAHz;
R.MAGEstJAHz = MAGEstJAHz;

end

