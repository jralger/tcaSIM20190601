
function Draw4CarbonsAsp(xc, yc, C, FE, FEC, MS, Msep, ID, AnnLoc)

xp = xc;
yp = yc + (1.5*Msep);
plot(xp,yp,'o', 'LineWidth', 2, 'MarkerEdgeColor', 'k', ...
           'MarkerFaceColor', 'w', 'MarkerSize', MS);
if FE(1) > 0
    plot(xp,yp,'o', 'MarkerEdgeColor', C, 'MarkerFaceColor', FEC, ...
               'MarkerSize', MS);
end

yp = yc + (0.5*Msep);
plot(xp,yp,'o', 'LineWidth', 2, 'MarkerEdgeColor', 'k', ...
           'MarkerFaceColor', 'w', 'MarkerSize', MS);
if FE(2) > 0
    plot(xp,yp,'o', 'MarkerEdgeColor', C, 'MarkerFaceColor', FEC, ...
               'MarkerSize', MS);
end

yp = yc - (0.5*Msep);
plot(xp,yp,'o', 'LineWidth', 2, 'MarkerEdgeColor', 'k', ...
           'MarkerFaceColor', 'w', 'MarkerSize', MS);
if FE(3) > 0
    plot(xp,yp,'o', 'MarkerEdgeColor', C, 'MarkerFaceColor', FEC, ...
               'MarkerSize', MS);
end

yp = yc - (1.5*Msep);
plot(xp,yp,'o', 'LineWidth', 2, 'MarkerEdgeColor', 'k', ...
           'MarkerFaceColor', 'w', 'MarkerSize', MS);
if FE(4) > 0
    plot(xp,yp,'o', 'MarkerEdgeColor', C, 'MarkerFaceColor', FEC, ...
               'MarkerSize', MS);
end




if AnnLoc == 'UR'
    xp = xc + (0.5*Msep);
    yp = yc + (1.0*Msep);
    text(xp, yp, ID)
 end
 if AnnLoc == 'UL'
    xp = xc - (0.5*Msep);
    yp = yc + (1.0*Msep);
    text(xp, yp, ID)
 end
 
 if AnnLoc == 'B'
    xp = xc;
    yp = yc - (2.0*Msep);
    t = text(xp, yp, ID);
    t.HorizontalAlignment = 'center';
 end
 


end

