function Mults = SimulateMolSpectra(MolID, Mults, V)

if strcmp(MolID, 'Glu')
    Mults = SimulateGluSpectra(Mults, V);
end

if strcmp(MolID, 'Asp')
    Mults = SimulateAspSpectra(Mults, V);
end

if strcmp(MolID, 'bHB')
    Mults = SimulatebHBSpectra(Mults, V);
end

if strcmp(MolID, 'Ala')
    Mults = SimulateAlaSpectra(Mults, V);
end

if strcmp(MolID, 'Glc')
    Mults = SimulateGlcSpectra(Mults, V);
end

if strcmp(MolID, 'MAG')
    Mults = SimulateMAGSpectra(Mults, V);
end


end

