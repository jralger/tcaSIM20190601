function Multiplets = BuildbHBDefaultMultiplets()

GlobalR2 = SetDefaultR2();

R = SetDefaultChemicalShifts();
FreqsPPM = R.bHBEstFreqsPPM;

R = SetDefaultJs();
JAHz = R.bHBEstJAHz;

% R = SetDefaultIsotopeShifts();

Spectrum = BuildDefaultSpectrum();

ID = 'bHB C1 S';
FreqPPM = FreqsPPM(1);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);

Multiplets = [Multiplet, ...  %1: bHB C1 S
              Multiplet, ...  %2: bHB C1 D
              Multiplet, ...  %3: bHB C2 S
              Multiplet, ...  %4: bHB C2 D12
              Multiplet, ...  %5: bHB C2 D23
              Multiplet, ...  %6: bHB C2 Q
              Multiplet, ...  %7: bHB C3 S
              Multiplet, ...  %8: bHB C3 D
              Multiplet, ...  %10: bHB C3 T
              Multiplet, ...  %11: bHB C4 S
              Multiplet]; ...  %12: bHB C4 D
n = 2;

ID = 'bHB C1 D';
FreqPPM = FreqsPPM(1);
JHz = JAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'bHB C2 S';
FreqPPM = FreqsPPM(2);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'bHB C2 D12';
FreqPPM = FreqsPPM(2);
JHz = JAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'bHB C2 D23';
FreqPPM = FreqsPPM(2);
JHz = JAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'bHB C2 Q';
FreqPPM = FreqsPPM(2);
JHz = [JAHz(1,2), JAHz(2,3)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'bHB C3 S';
FreqPPM = FreqsPPM(3);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

% ID = 'bHB C3 D23';
% FreqPPM = FreqsPPM(3);
% JHz = JAHz(2,3);
% Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
% Multiplets(n) = Multiplet;
% n = n + 1;
% 
% ID = 'bHB C3 D34';
% FreqPPM = FreqsPPM(3);
% JHz = JAHz(3,4);
% Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
% Multiplets(n) = Multiplet;
% n = n + 1;
% 
% ID = 'bHB C3 Q';
% FreqPPM = FreqsPPM(3);
% JHz = [JAHz(3,4), JAHz(2,3)];
% Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
% Multiplets(n) = Multiplet;
% n = n + 1;

ID = 'bHB C3 D';
FreqPPM = FreqsPPM(3);
JHz = JAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'bHB C3 T';
FreqPPM = FreqsPPM(3);
JHz = [JAHz(3,4), JAHz(2,3)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'bHB C4 S';
FreqPPM = FreqsPPM(4);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'bHB C4 D';
FreqPPM = FreqsPPM(4);
JHz = JAHz(3,4);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;

end

