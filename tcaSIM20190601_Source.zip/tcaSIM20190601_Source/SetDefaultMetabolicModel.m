function MetabolicModel = SetDefaultMetabolicModel()
MetabolicModel.ExptID = 'A';
MetabolicModel.Ys = 0.0;
MetabolicModel.GlnYs = 0.0;
MetabolicModel.GK = 0.0;
MetabolicModel.YPC = 0.0;
MetabolicModel.PDH = 0.0;
MetabolicModel.PK = 0.0;
MetabolicModel.ROF = 1.0;
MetabolicModel.RSM = 0.5;
MetabolicModel.TPI = 1.0;
MetabolicModel.EaKG = 0.0;
MetabolicModel.ECit = 0.0;
MetabolicModel.EOAA = 0.0;
MetabolicModel.nTurns = 35;
MetabolicModel.ExactNaturalAbundance = 1;
end

