function G6P = Gluconeogenesis(DHAP, GA3P, G6P, m)

% DHAP C1 ---> G6P C3
% DHAP C2 ---> G6P C2
% DHAP C3 ---> G6P C1
% 
% GA3P C1 ---> Glc C1
% GA3P C2 ---> G6P C2
% GA3P C3 ---> G6P C3

[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
                                
[oooooo, xooooo, oxoooo, xxoooo, ...
 ooxooo, xoxooo, oxxooo, xxxooo, ...
 oooxoo, xooxoo, oxoxoo, xxoxoo, ...
 ooxxoo, xoxxoo, oxxxoo, xxxxoo, ...
 ooooxo, xoooxo, oxooxo, xxooxo, ...
 ooxoxo, xoxoxo, oxxoxo, xxxoxo, ...
 oooxxo, xooxxo, oxoxxo, xxoxxo, ...
 ooxxxo, xoxxxo, oxxxxo, xxxxxo, ...
 ooooox, xoooox, oxooox, xxooox, ...
 ooxoox, xoxoox, oxxoox, xxxoox, ...
 oooxox, xooxox, oxoxox, xxoxox, ...
 ooxxox, xoxxox, oxxxox, xxxxox, ...
 ooooxx, xoooxx, oxooxx, xxooxx, ...
 ooxoxx, xoxoxx, oxxoxx, xxxoxx, ...
 oooxxx, xooxxx, oxoxxx, xxoxxx, ...
 ooxxxx, xoxxxx, oxxxxx, xxxxxx] ...
                                  = DefineSixCarbonLabelIndices();
                              
 G6P(m, oooooo) = DHAP(m, ooo)*GA3P(m,ooo);
 G6P(m, xooooo) = DHAP(m, oox)*GA3P(m,ooo);
 G6P(m, oxoooo) = DHAP(m, oxo)*GA3P(m,ooo);
 G6P(m, xxoooo) = DHAP(m, oxx)*GA3P(m,ooo);
 
 G6P(m, ooxooo) = DHAP(m, xoo)*GA3P(m,ooo);
 G6P(m, xoxooo) = DHAP(m, xox)*GA3P(m,ooo);
 G6P(m, oxxooo) = DHAP(m, xxo)*GA3P(m,ooo);
 G6P(m, xxxooo) = DHAP(m, xxx)*GA3P(m,ooo);
 
 G6P(m, oooxoo) = DHAP(m, ooo)*GA3P(m,xoo);
 G6P(m, xooxoo) = DHAP(m, oox)*GA3P(m,xoo);
 G6P(m, oxoxoo) = DHAP(m, oxo)*GA3P(m,xoo);
 G6P(m, xxoxoo) = DHAP(m, oxx)*GA3P(m,xoo);
 
 G6P(m, ooxxoo) = DHAP(m, xoo)*GA3P(m,xoo);
 G6P(m, xoxxoo) = DHAP(m, xox)*GA3P(m,xoo);
 G6P(m, oxxxoo) = DHAP(m, xxo)*GA3P(m,xoo);
 G6P(m, xxxxoo) = DHAP(m, xxx)*GA3P(m,xoo);
                           
 G6P(m, ooooxo) = DHAP(m, ooo)*GA3P(m,oxo);
 G6P(m, xoooxo) = DHAP(m, oox)*GA3P(m,oxo);
 G6P(m, oxooxo) = DHAP(m, oxo)*GA3P(m,oxo);
 G6P(m, xxooxo) = DHAP(m, oxx)*GA3P(m,oxo);
 
 G6P(m, ooxoxo) = DHAP(m, xoo)*GA3P(m,oxo);
 G6P(m, xoxoxo) = DHAP(m, xox)*GA3P(m,oxo);
 G6P(m, oxxoxo) = DHAP(m, xxo)*GA3P(m,oxo);
 G6P(m, xxxoxo) = DHAP(m, xxx)*GA3P(m,oxo);
 
 G6P(m, oooxxo) = DHAP(m, ooo)*GA3P(m,xxo);
 G6P(m, xooxxo) = DHAP(m, oox)*GA3P(m,xxo);
 G6P(m, oxoxxo) = DHAP(m, oxo)*GA3P(m,xxo);
 G6P(m, xxoxxo) = DHAP(m, oxx)*GA3P(m,xxo);
 
 G6P(m, ooxxxo) = DHAP(m, xoo)*GA3P(m,xxo);
 G6P(m, xoxxxo) = DHAP(m, xox)*GA3P(m,xxo);
 G6P(m, oxxxxo) = DHAP(m, xxo)*GA3P(m,xxo);
 G6P(m, xxxxxo) = DHAP(m, xxx)*GA3P(m,xxo);
 
 G6P(m, ooooox) = DHAP(m, ooo)*GA3P(m,oox);
 G6P(m, xoooox) = DHAP(m, oox)*GA3P(m,oox);
 G6P(m, oxooox) = DHAP(m, oxo)*GA3P(m,oox);
 G6P(m, xxooox) = DHAP(m, oxx)*GA3P(m,oox);
 
 G6P(m, ooxoox) = DHAP(m, xoo)*GA3P(m,oox);
 G6P(m, xoxoox) = DHAP(m, xox)*GA3P(m,oox);
 G6P(m, oxxoox) = DHAP(m, xxo)*GA3P(m,oox);
 G6P(m, xxxoox) = DHAP(m, xxx)*GA3P(m,oox);
 
 G6P(m, oooxox) = DHAP(m, ooo)*GA3P(m,xox);
 G6P(m, xooxox) = DHAP(m, oox)*GA3P(m,xox);
 G6P(m, oxoxox) = DHAP(m, oxo)*GA3P(m,xox);
 G6P(m, xxoxox) = DHAP(m, oxx)*GA3P(m,xox);
 
 G6P(m, ooxxox) = DHAP(m, xoo)*GA3P(m,xox);
 G6P(m, xoxxox) = DHAP(m, xox)*GA3P(m,xox);
 G6P(m, oxxxox) = DHAP(m, xxo)*GA3P(m,xox);
 G6P(m, xxxxox) = DHAP(m, xxx)*GA3P(m,xox);
                           
 G6P(m, ooooxx) = DHAP(m, ooo)*GA3P(m,oxx);
 G6P(m, xoooxx) = DHAP(m, oox)*GA3P(m,oxx);
 G6P(m, oxooxx) = DHAP(m, oxo)*GA3P(m,oxx);
 G6P(m, xxooxx) = DHAP(m, oxx)*GA3P(m,oxx);
 
 G6P(m, ooxoxx) = DHAP(m, xoo)*GA3P(m,oxx);
 G6P(m, xoxoxx) = DHAP(m, xox)*GA3P(m,oxx);
 G6P(m, oxxoxx) = DHAP(m, xxo)*GA3P(m,oxx);
 G6P(m, xxxoxx) = DHAP(m, xxx)*GA3P(m,oxx);
 
 G6P(m, oooxxx) = DHAP(m, ooo)*GA3P(m,xxx);
 G6P(m, xooxxx) = DHAP(m, oox)*GA3P(m,xxx);
 G6P(m, oxoxxx) = DHAP(m, oxo)*GA3P(m,xxx);
 G6P(m, xxoxxx) = DHAP(m, oxx)*GA3P(m,xxx);
 
 G6P(m, ooxxxx) = DHAP(m, xoo)*GA3P(m,xxx);
 G6P(m, xoxxxx) = DHAP(m, xox)*GA3P(m,xxx);
 G6P(m, oxxxxx) = DHAP(m, xxo)*GA3P(m,xxx);
 G6P(m, xxxxxx) = DHAP(m, xxx)*GA3P(m,xxx);
 
end

