function WritePreambleTCAS(fileID, VersionID, ExptID)
txt = 'Copyright: 2018 UTSouthwestern Advanced Imaging Research Center\n';
fprintf(fileID, txt);

txt = 'All rights reserved\n';
fprintf(fileID, txt);

txt = 'Design by NeuroSpectroScopics LLC\n';
fprintf(fileID, txt);

txt = 'www.neurospectroscopics.com\n';
fprintf(fileID, txt);

txt1 = 'Acknowledgement for publications: ';
txt2 = 'Development of tcaSIM ';
txt3 = 'was supported by funding from NIH/NIBIB P41 EB015908\n ';
txt = [txt1, txt2, txt3];
fprintf(fileID, txt);

txt = 'NOT FOR CLINICAL USE\n';
fprintf(fileID, txt);

txt = '\n';
fprintf(fileID, txt);

txt = '\n';
fprintf(fileID, txt);

txt = '\n';
fprintf(fileID, txt);

txt = '\n';
fprintf(fileID, txt);

txt = ['tcaSIM Metabolic Simulator Version: ', VersionID, '\n'];
fprintf(fileID, txt);

txt = ['Experiment ID: ', ExptID, '\n'];
fprintf(fileID, txt);

txt = char(datetime('now'));
txt = ['tcaSim Run Date/Time: ', txt, '\n'];
fprintf(fileID, txt);
end

