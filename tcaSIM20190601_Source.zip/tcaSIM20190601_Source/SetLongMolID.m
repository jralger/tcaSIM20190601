function LMolID = SetLongMolID(MolID)

LMolID = 'Null';

if strcmp(MolID, 'Glu')
    LMolID = 'Glutamate';
end

if strcmp(MolID, 'Ala')
    LMolID = 'Alanine';
end

if strcmp(MolID, 'Asp')
    LMolID = 'Aspartate';
end

if strcmp(MolID, 'bHB')
    LMolID = 'beta-Hydroxybutyrate';
end

if strcmp(MolID, 'Glc')
    LMolID = 'Glucose';
end

if strcmp(MolID, 'MAG')
    LMolID = 'MonoAcetone Glucose';
end

end

