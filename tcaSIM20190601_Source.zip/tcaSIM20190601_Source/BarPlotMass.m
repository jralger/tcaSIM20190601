function BarPlotMass(A, m, Title, C)
V = A(m, :);
nV = size(V, 2);
xlabs = BuildMassIDs(nV);

bar(V, C);
maxA = max(A);
maxA = max(maxA);
if maxA == 0
    maxA = 1;
end
% axis([0, maxA, 0, nV+1]);
axis([0, nV+1, 0, maxA]);

title(Title);

set(gca, 'XTick', 1:nV);
set(gca, 'XTickLabel', xlabs);
set(gca, 'TickDir', 'out');
set(gca, 'Box', 'off');

ylabel('Enrichment');
xlabel('Mass');

end

