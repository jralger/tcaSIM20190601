function [o, x] = DefineOneCarbonLabelIndices()

% This function defines the label indices for a one carbon molecule (HCO3)
% using notation developed by Craig Malloy 
% o means C12 and x means C13
% eg x means a one carbon moelcule labelled with C13
% there are no inputs
% returns the numerical values of indices for all possible isotopomers 

o = 1;
x = 2;

end

