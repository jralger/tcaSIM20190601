function Multiplets = BuildMAGDefaultMultiplets()

GlobalR2 = SetDefaultR2();

R = SetDefaultChemicalShifts();
FreqsPPM = R.MAGEstFreqsPPM;

R = SetDefaultJs();
JAHz = R.MAGEstJAHz;

% R = SetDefaultIsotopeShifts();

Spectrum = BuildDefaultSpectrum();

ID = 'MAG C1 S';
FreqPPM = FreqsPPM(1);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);

Multiplets = [Multiplet, ...  %1: MAG C1 S
              Multiplet, ...  %2: MAG C1 D
              Multiplet, ...  %3: MAG C2 S
              Multiplet, ...  %4: MAG C2 D12
              Multiplet, ...  %5: MAG C2 D23
              Multiplet, ...  %6: MAG C2 Q
              Multiplet, ...  %7: MAG C3 S
              Multiplet, ...  %8: MAG C3 D23
              Multiplet, ...  %9: MAG C3 D34
              Multiplet, ...  %10: MAG C3 Q
              Multiplet, ...  %11: MAG C4 S
              Multiplet, ...  %12: MAG C4 D34
              Multiplet, ...  %13: MAG C4 D45
              Multiplet, ...  %14: MAG C4 Q
              Multiplet, ...  %15: MAG C5 S
              Multiplet, ...  %16: MAG C5 D45
              Multiplet, ...  %17: MAG C5 D56
              Multiplet, ...  %18: MAG C5 Q
              Multiplet, ...  %19: MAG C6 S
              Multiplet];     %20: MAG C6 D
              
n = 2;

ID = 'MAG C1 D';
FreqPPM = FreqsPPM(1);
JHz = JAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C2 S';
FreqPPM = FreqsPPM(2);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C2 D12';
FreqPPM = FreqsPPM(2);
JHz = JAHz(1,2);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C2 D23';
FreqPPM = FreqsPPM(2);
JHz = JAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C2 Q';
FreqPPM = FreqsPPM(2);
JHz = [JAHz(1,2), JAHz(2,3)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C3 S';
FreqPPM = FreqsPPM(3);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C3 D23';
FreqPPM = FreqsPPM(3);
JHz = JAHz(2,3);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C3 D34';
FreqPPM = FreqsPPM(3);
JHz = JAHz(3,4);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C3 Q';
FreqPPM = FreqsPPM(3);
JHz = [JAHz(2,3), JAHz(3,4)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C4 S';
FreqPPM = FreqsPPM(4);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C4 D34';
FreqPPM = FreqsPPM(4);
JHz = JAHz(3,4);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C4 D45';
FreqPPM = FreqsPPM(4);
JHz = JAHz(4,5);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C4 Q';
FreqPPM = FreqsPPM(4);
JHz = [JAHz(3,4), JAHz(4,5)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C5 S';
FreqPPM = FreqsPPM(5);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C5 D45';
FreqPPM = FreqsPPM(5);
JHz = JAHz(4,5);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C5 D56';
FreqPPM = FreqsPPM(5);
JHz = JAHz(5,6);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C5 Q';
FreqPPM = FreqsPPM(5);
JHz = [JAHz(5,6), JAHz(4,5)];
Multiplet = BuildQuartet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C6 S';
FreqPPM = FreqsPPM(6);
Multiplet = BuildSinglet(ID, Spectrum, FreqPPM, GlobalR2);
Multiplets(n) = Multiplet;
n = n + 1;

ID = 'MAG C6 D';
FreqPPM = FreqsPPM(6);
JHz = JAHz(5,6);
Multiplet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2);
Multiplets(n) = Multiplet;




