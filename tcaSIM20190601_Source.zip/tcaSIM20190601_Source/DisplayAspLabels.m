function DisplayAspLabels(Asp, Title, DrawAll)

F1 = figure('Name', 'Asp', ...
            'Color', 'w', ...
            'Units', 'Normalized',  ...
            'Position', [0.1, 0.1, 0.8, 0.8]);

nTurns = size(Asp,1);
title(Title);

hold on;

C = 'k';
FEC = 'r';
MS = 12;
Msep = 0.11;

IDs = BuildIsotopomerIDs(16);

Concs = Asp(nTurns, :);

xc = 1.0;
yc = 4.0;

for i = 1:16
    ID = char(IDs(i));
    Conc = Concs(i);
    FE = XO2FE(ID);
    U = sprintf('%5.3f',Conc); 
    txt = [ID, ' Conc: ', U];
    if DrawAll == 1
        Draw4CarbonsAsp(xc, yc, C, FE, FEC, MS, Msep, txt, 'UR');
        xc = xc + 1.0;
        if xc > 4.0
            yc = yc - 1.0;
            xc = 1.0;
        end
    end
    if  DrawAll == 0   
        if Conc > 0
            Draw4CarbonsAsp(xc, yc, C, FE, FEC, MS, Msep, txt, 'UR');
            xc = xc + 1.0;
            if xc > 4.0
                yc = yc - 1.0;
                xc = 1.0;
            end
        end
    end
end
axis([0, 5, 0, 5]);

axis off;

