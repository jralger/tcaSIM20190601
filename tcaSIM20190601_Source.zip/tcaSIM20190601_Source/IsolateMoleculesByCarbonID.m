function RMolecules = IsolateMoleculesByCarbonID(Molecules, TID)
nMols = size(Molecules, 1);
n = 1;
RMolecules = Molecules;
for i = 1:nMols
    Molecule = Molecules(i);
    ID = Molecule.ID;
    ID = strsplit(ID);
    ID = [char(ID(1)), ' ', char(ID(2))];
    CID = char(TID);
    if strcmp(ID, CID)
        RMolecules(n) = Molecule;
        n = n + 1;
    end
end
n = n - 1;
RMolecules = RMolecules(1:n);
end

