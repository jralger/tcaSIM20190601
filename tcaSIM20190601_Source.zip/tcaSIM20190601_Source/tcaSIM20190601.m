function varargout = tcaSIM20190601(varargin)
% Edit the above text to modify the response to help tcaSIM20190601

% Last Modified by GUIDE v2.5 20-May-2019 18:21:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tcaSIM20190601_OpeningFcn, ...
                   'gui_OutputFcn',  @tcaSIM20190601_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

function hObject = CheckFixNegatives(hObject)
 V = str2double(get(hObject,'String'));
 if V < 0
     hObject.String = sprintf('%4.2f',0);
 end

function tcaSIM20190601_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for tcaSIM20190601
handles.output = hObject;

axes(handles.axes1);
cla;
P = imread('tcaSIM _Simple Version_5172019.png');
image(P);
axis off;

UseExactNA = 0;
Substrates = SetDefaultSubstrates(UseExactNA);
handles.Lac = Substrates.Lac;
handles.FA = Substrates.FA;
handles.Gln = Substrates.Gln;
handles.CO2 = Substrates.CO2;
handles.Glyc = Substrates.Glyc;
handles.SuccYs = Substrates.SuccYs;

MetabolicModel = SetDefaultMetabolicModel();
handles.GlnYs.String = sprintf('%5.2f', MetabolicModel.GlnYs);
handles.YPC.String = sprintf('%5.2f', MetabolicModel.YPC);
handles.PDH.String = sprintf('%4.2f', MetabolicModel.PDH);
handles.PK.String = sprintf('%5.2f', MetabolicModel.PK);
handles.nTurns.String = sprintf('%4.0f', MetabolicModel.nTurns);
handles.ExptID.String = MetabolicModel.ExptID;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tcaSIM20190601 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tcaSIM20190601_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%% All CreateFcn %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function AcCheck_CreateFcn(hObject, eventdata, handles)

function GlnCheck_CreateFcn(hObject, eventdata, handles)

function GlnYs_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end    

function YPC_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PDH_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PK_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function nTurns_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function axes1_CreateFcn(hObject, eventdata, handles)

function ExptID_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), ...
                   get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%% End All CreateFcn %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%% All DeleteFcn %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function figure1_DeleteFcn(hObject, eventdata, handles)
%Do not understand why this is needed

%%%%%%%%%%%%%%%%%% End All DeleteFcn %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%% All Callback  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function GlnYs_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
Ys = str2double(get(hObject,'String'));
hObject.String = sprintf('%5.2f',Ys);
guidata(hObject, handles);

function YPC_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
YPC = str2double(get(hObject,'String'));
hObject.String = sprintf('%5.2f',YPC);
guidata(hObject, handles);

function PDH_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
PDH = str2double(get(hObject,'String'));
hObject.String = sprintf('%4.2f',PDH);
if PDH > 1
    hObject.String = sprintf('%4.2f',1.0);
end
guidata(hObject, handles);

function PK_Callback(hObject, eventdata, handles)
hObject = CheckFixNegatives(hObject);
PK = str2double(get(hObject,'String'));
hObject.String = sprintf('%5.2f',PK);
guidata(hObject, handles);

function Done_Callback(hObject, eventdata, handles)
close;

function AdvancedMode_Callback(hObject, eventdata, handles)
close;
tcaSIM_Advanced;

function nTurns_Callback(hObject, eventdata, handles)
V = str2double(get(hObject,'String'));
if V < 1
    hObject.String = ['1'];
end
nTurns = round(str2double(get(hObject,'String')));
hObject.String = sprintf('%4.0f',nTurns);
guidata(hObject, handles);

function SkipGluOutput_Callback(hObject, eventdata, handles)
% handles seems to be automatically updated

function SkipMultiplets_Callback(hObject, eventdata, handles)
% handles seems to be automatically updated

function SkipMAGOutput_Callback(hObject, eventdata, handles)
% handles seems to be automatically updated

function ExptID_Callback(hObject, eventdata, handles)
guidata(hObject, handles);

function AcCheck_Callback(hObject, eventdata, handles)
FA = handles.FA;
MolID = 'Acetate (Fatty Acid Equivalent)';
FA = InputTwoCarbonIsotopomers('InputFA', MolID, FA);
handles.FA = FA;
Z = handles.AcCheck;
[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
if FA(1,oo) ~= 1.0
    Z.Value = 1;
    handles.AcCheck = Z;
end
if FA(1,oo) == 1.0
    Z.Value = 0;
    handles.AcCheck = Z;
end
guidata(hObject, handles);

function LacCheck_Callback(hObject, eventdata, handles)
Lac = handles.Lac;
MolID = 'Lactate';
Lac = InputThreeCarbonIsotopomers('InputLac', MolID, Lac);
handles.Lac = Lac;
Z = handles.LacCheck;
[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
if Lac(1,ooo) ~= 1.0
    Z.Value = 1;
    handles.LacCheck = Z;
end
if Lac(1,ooo) == 1.0
    Z.Value = 0;
    handles.LacCheck = Z; 
end
guidata(hObject, handles);
    
function GlnCheck_Callback(hObject, eventdata, handles)
Gln = handles.Gln;
MolID = 'Glutamine';
Gln = InputFiveCarbonIsotopomers('InputGln', MolID, Gln);
handles.Gln = Gln;
Z = handles.GlnCheck;
                                
[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();
if Gln(1,ooooo) ~= 1.0
    Z.Value = 1;
    handles.GlnCheck = Z;
end
if Gln(1,ooooo) == 1.0
    Z.Value = 0;
    handles.GlnCheck = Z;
end
guidata(hObject, handles);

function RuntcaSIMGUIInput_Callback(hObject, eventdata, handles)
NoInputTest = 0;
LDHFailTest = 0;

MetabolicModel = SetDefaultMetabolicModel;
MetabolicModel.ExptID = handles.ExptID.String;
MetabolicModel.GlnYs = str2double(handles.GlnYs.String);
MetabolicModel.Ys = 0.0;
MetabolicModel.YPC = str2double(handles.YPC.String);
MetabolicModel.PDH = str2double(handles.PDH.String);
MetabolicModel.PK = str2double(handles.PK.String);
MetabolicModel.nTurns = str2double(handles.nTurns.String);
MetabolicModel.ExactNaturalAbundance = 0;

Substrates = SetDefaultSubstrates(MetabolicModel.ExactNaturalAbundance);
Substrates.Lac = handles.Lac;
Substrates.FA = handles.FA;
Substrates.Gln = handles.Gln;

SkipOutput = SetDefaultSkipOutput();

if handles.SkipMultiplets.Value
    SkipOutput.MultStackedPlots = 1;
else
    SkipOutput.MultStackedPlots = 0;
end

if handles.SkipMAGOutput.Value
    SkipOutput.MAG = 1;
else
    SkipOutput.MAG = 0;
end

if handles.SkipGluOutput.Value
    SkipOutput.Glu = 1;
else
    SkipOutput.Glu = 0;
end

if NoInputTest == 1
    NoInputODN = 'C:\Users\Jeffry R Alger\Desktop\tcaSIMtest';
    
    Lac = zeros(1,8);
    [ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                        DefineThreeCarbonLabelIndices();
    Lac(1, xxx) = 0.65;
    Lac = UpdateUnLabelledIsotopomer(Lac);
    Substrates.Lac = Lac;
    
    FA = zeros(1,4);
    [oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
    FA(1, ox) = 0.35;
    FA(1, xo) = 0.37;
    FA(1, xx) = 1- sum(FA) - 0.03;
    FA = UpdateUnLabelledIsotopomer(FA);
    Substrates.FA = FA;

    Gln = zeros(1,32);
    [ooooo, xoooo, oxooo, xxooo, ...
     ooxoo, xoxoo, oxxoo, xxxoo, ...
     oooxo, xooxo, oxoxo, xxoxo, ...
     ooxxo, xoxxo, oxxxo, xxxxo, ...
     oooox, xooox, oxoox, xxoox, ...
     ooxox, xoxox, oxxox, xxxox, ...
     oooxx, xooxx, oxoxx, xxoxx, ...
     ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();    
    Gln(1, xxxxx) = 0.95;
    Gln = UpdateUnLabelledIsotopomer(Gln);
    Substrates.Gln = Gln;

    MetabolicModel.ExptID = 'TestOutput';
    
    ODN = NoInputODN;
end

if LDHFailTest
    S = MetabolicModel.YPC + MetabolicModel.PDH;
    MetabolicModel.PK = S + 1;
end
    
LDH = MetabolicModel.YPC + MetabolicModel.PDH - MetabolicModel.PK;
if LDH < 0
    FailLDHMsgBox();
else
    if NoInputTest == 0
        txt = 'Browse to tcaSIM Output Folder.';
        SP = cd;
        ODN = uigetdir(SP, txt);
        Q = strcmp(SP, ODN);
        while Q
            txt = 'Output folder can not be the same as the source code folder.  Browse to tcaSIM Output Folder.' ;
            ODN = uigetdir(SP, txt);
            Q = strcmp(SP, ODN);
        end
    end
    RuntcaSIM(ODN, Substrates, MetabolicModel, 0, SkipOutput);
    SuccessMsgBox();
end

