function BarhIsotopomerMovie(A, Title, C, FN)
V = A(1, :);
nV = size(V, 2);
xos = BuildIsotopomerIDs(nV);
nTurns = size(A, 1);

figure('Color', 'w', 'Position', [50, 50, 1024, 1024]);

barh(V, C);
maxA = max(A);
maxA = max(maxA);
if maxA == 0
    maxA = 1;
end
axis([0, maxA, 0, nV+1]);
% axis([0, 1.0, 0, nV+1]);
xlabel('Enrichment');
ylabel('Isotopomer');
set(gca, 'YTick', 1:nV);
set(gca, 'YTickLabel', xos);
set(gca, 'TickDir', 'out');
set(gca, 'Box', 'off');
txt = [Title, ' Turn ', num2str(1)];
title(txt);

M = getframe(gcf);
nM = 8*(nTurns+1);
M = repelem(M, nM);

n = 1;
for i = 1:8
    M(n) = getframe(gcf);
    n = n + 1;
end

for i = 1:nTurns
    V = A(i, :);
    barh(V, C);
    txt = [Title, ' Turn ', num2str(i)];
    title(txt);
    axis([0, 1.0, 0, nV+1])
    xlabel('Enrichment')
    ylabel('Isotopomer')
    set(gca, 'YTick', 1:nV);
    set(gca, 'YTickLabel', xos);
    set(gca, 'TickDir', 'out');
    set(gca, 'Box', 'off')
    for j = 1:8
        M(n) = getframe(gcf);
        n = n + 1;
    end
end

txt = 'Please wait. Writing video.';
h = waitbar(2,txt);
v = VideoWriter(FN,'MPEG-4');
open(v);
writeVideo(v,M);
close(v);
close(h);

end

