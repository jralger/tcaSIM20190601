function ConcWtdSpectrum = GetSpectrumFromMultiplets(Multiplets, PPMR)
Mult = Multiplets(1,1);
nM = size(Multiplets, 2);
ConcWtdSpectrum = Mult.ConcWtdSpectrum;

for j=1:nM
    Mult = Multiplets(1,j);
    CWS = Mult.ConcWtdSpectrum;
    FD = CWS.FreqDomainData;
%     PPMT = CWS.PPMTable;
%     FreqPPM = Mult.FreqPPM;
%     PPMH = FreqPPM + (PPMR/2.0);
%     FD(PPMT > PPMH) = complex(0.0, 0.0);
%     PPML = PlotCenter - (PPMR/2.0);
%     FD(PPMT < PPML) = complex(0.0, 0.0);
    if j == 1
        TFD = FD;
    end
    if j > 1
        TFD = FD + TFD;
    end
ConcWtdSpectrum.FreqDomainData = TFD;
end

