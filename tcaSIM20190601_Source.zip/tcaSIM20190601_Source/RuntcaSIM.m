function RuntcaSIM(ODN, Substrates, MetabolicModel, axes7, SkipOutput)
SimMsgBox();
% RFNs = dir(ODN);
% nRFNs = size(RFNs, 1);
% if nRFNs ~= 0
%     rmdir(ODN, 's');
% end
% mkdir(ODN);

SkipAnimation = SkipOutput.SkipAnimation;
SkipMultipletPlots = SkipOutput.MultStackedPlots;
SkipMolDiagram = SkipOutput.MolLabelDiagram;
SkipGluOutput = SkipOutput.Glu;
SkipAlaOutput = SkipOutput.Ala;
SkipAspOutput = SkipOutput.Asp;
SkipbHBOutput = SkipOutput.bHB;
% SkipGlcOutput = SkipOutput.Glc;
SkipMAGOutput = SkipOutput.MAG;

ExptID = MetabolicModel.ExptID;
Ys = MetabolicModel.Ys;
GlnYs = MetabolicModel.GlnYs;
GK = MetabolicModel.GK;
Ypc = MetabolicModel.YPC;
PDH = MetabolicModel.PDH;
PK = MetabolicModel.PK;
ROF = MetabolicModel.ROF;
RSM = MetabolicModel.RSM;
TPI = MetabolicModel.TPI;
EaKG2aKG = MetabolicModel.EaKG;
ECit2Cit = MetabolicModel.ECit;
EOAA2OAA = MetabolicModel.EOAA;
nTCAturns = MetabolicModel.nTurns;

ICO2 = Substrates.CO2;
IFAs = Substrates.FA;
ILac = Substrates.Lac;
IGlyc = Substrates.Glyc;
ISuccYs = Substrates.SuccYs;
IGln = Substrates.Gln;
IGlc = zeros(1, 64);

Q = GlnYs + Ys;
if Q > 0
    [ICO2_GlnYs, ISucc_GlnYs] = ...
                 aKetoGlutarateDehydrogenase(IGln, ISuccYs, ICO2, 1);
    RA = GlnYs/(GlnYs + Ys);
    ISuccYs = CombineTwoLabelPools(ISucc_GlnYs, ISuccYs, 1, RA);
%     ICO2 = CombineTwoLabelPools(ICO2_GlnYs, ICO2, 1, RA);
    Ys = Ys + GlnYs;
end

[Isotops, VersionID] = ...
    SimulateIsotopomers(...
    nTCAturns, ...
    GK, PDH, PK, ROF, RSM, TPI, Ypc, Ys, ...
    EaKG2aKG, ECit2Cit, EOAA2OAA, ....
    ICO2, IFAs, IGlc, IGlyc, ILac, ISuccYs, ...
    MetabolicModel.ExactNaturalAbundance);

WriteExptParameters(ODN, Substrates, MetabolicModel);

gcf;
close;

if axes7 ~= 0
    for n = 1:nTCAturns
        axes(axes7);
        cla;
        txt = ['Expt ', ExptID,': aKG at Turn ',num2str(n)];
        BarhPlotIsotopomerEnrichment(Isotops.aKG, n, txt, 'b');
        %         pause(0.25);
    end
end


if SkipGluOutput == 0
    Glu = Isotops.aKG;
    DisplayDumpMolResults('Glu', Glu, ExptID, ODN, VersionID, ...
        SkipAnimation, SkipMultipletPlots, ...
        SkipMolDiagram);
end

if SkipAspOutput == 0
    Asp = Isotops.OAA;
    DisplayDumpMolResults('Asp', Asp, ExptID, ODN, VersionID, ...
        SkipAnimation, SkipMultipletPlots, ...
        SkipMolDiagram);
end

if SkipbHBOutput == 0
    bHB = Isotops.bHB;
    DisplayDumpMolResults('bHB', bHB, ExptID, ODN, VersionID, ...
        SkipAnimation, SkipMultipletPlots, ...
        SkipMolDiagram);
end

if SkipAlaOutput == 0
    Ala = Isotops.Ala;
    DisplayDumpMolResults('Ala', Ala, ExptID, ODN, VersionID, ...
        SkipAnimation, SkipMultipletPlots, ...
        SkipMolDiagram);
end

% if SkipGlcOutput == 0
%     Glc = Isotops.Glc;
%     DisplayDumpMolResults('Glc', Glc, ExptID, ODN, VersionID, ...
%         SkipAnimation, SkipMultipletPlots, ...
%         SkipMolDiagram);
% end

if SkipMAGOutput == 0
    MAG = Isotops.Glc;
    DisplayDumpMolResults('MAG', MAG, ExptID, ODN, VersionID, ...
        SkipAnimation, SkipMultipletPlots, ...
        SkipMolDiagram);
end




