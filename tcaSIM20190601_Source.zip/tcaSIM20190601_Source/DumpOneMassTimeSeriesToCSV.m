function DumpOneMassTimeSeriesToCSV(M, MID, FN, ExptID, VersionID)

Mass = Isotopomers2Isotopologues(M);
nMass = size(Mass, 2);
MassIDs = BuildMassIDs(nMass);
nTCAturns = size(Mass, 1);

fileID = fopen(FN, 'w');
txt = 'tcaSIM Mass Simulation\n';
fprintf(fileID, txt);

WritePreambleTCAS(fileID, VersionID, ExptID);

txt = ',,Mass At Turn Number\n';
fprintf(fileID, txt);

txt = 'MoleculeID,MassID,';
for i=1:nTCAturns
    txt = [txt,num2str(i),','];
end
txt = [txt,'\n'];
fprintf(fileID, txt);

for i = 1:nMass
    txt = [MID, ',', char(MassIDs(i)), ','];
    V = Mass(:, i);
    for j = 1:nTCAturns
        txt = [txt, num2str(V(j)), ','];
    end
    txt = [txt, '\n'];
    fprintf(fileID, txt);
end
fclose(fileID);
end

