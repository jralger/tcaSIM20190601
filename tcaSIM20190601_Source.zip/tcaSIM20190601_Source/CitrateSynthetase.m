function Cit_CS = CitrateSynthetase(OAA, AcA, Cit, m)
% OAA + AcA ---> citrate

% OAA C1 --> citrate C6
% OAA C2 --> citrate C3
% OAA C3 --> citrate C2
% OAA C4 --> citrate C1

% AcA C1 ---> citrate C5
% AcA C2 ---> citrate C4

[oooooo, xooooo, oxoooo, xxoooo, ...
 ooxooo, xoxooo, oxxooo, xxxooo, ...
 oooxoo, xooxoo, oxoxoo, xxoxoo, ...
 ooxxoo, xoxxoo, oxxxoo, xxxxoo, ...
 ooooxo, xoooxo, oxooxo, xxooxo, ...
 ooxoxo, xoxoxo, oxxoxo, xxxoxo, ...
 oooxxo, xooxxo, oxoxxo, xxoxxo, ...
 ooxxxo, xoxxxo, oxxxxo, xxxxxo, ...
 ooooox, xoooox, oxooox, xxooox, ...
 ooxoox, xoxoox, oxxoox, xxxoox, ...
 oooxox, xooxox, oxoxox, xxoxox, ...
 ooxxox, xoxxox, oxxxox, xxxxox, ...
 ooooxx, xoooxx, oxooxx, xxooxx, ...
 ooxoxx, xoxoxx, oxxoxx, xxxoxx, ...
 oooxxx, xooxxx, oxoxxx, xxoxxx, ...
 ooxxxx, xoxxxx, oxxxxx, xxxxxx] ...
                                   = DefineSixCarbonLabelIndices();

[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();

[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx , oxxx, xxxx] = ... 
                                          DefineFourCarbonLabelIndices();

Cit_CS = Cit;                                      
Cit_CS(m, oooooo) = OAA(m, oooo)*AcA(m,oo);
Cit_CS(m, xooooo) = OAA(m, ooox)*AcA(m,oo);
Cit_CS(m, oxoooo) = OAA(m, ooxo)*AcA(m,oo);
Cit_CS(m, xxoooo) = OAA(m, ooxx)*AcA(m,oo);

Cit_CS(m, ooxooo) = OAA(m, oxoo)*AcA(m,oo);
Cit_CS(m, xoxooo) = OAA(m, oxox)*AcA(m,oo);
Cit_CS(m, oxxooo) = OAA(m, oxxo)*AcA(m,oo);
Cit_CS(m, xxxooo) = OAA(m, oxxx)*AcA(m,oo);

Cit_CS(m, oooxoo) = OAA(m, oooo)*AcA(m,ox);
Cit_CS(m, xooxoo) = OAA(m, ooox)*AcA(m,ox);
Cit_CS(m, oxoxoo) = OAA(m, ooxo)*AcA(m,ox);
Cit_CS(m, xxoxoo) = OAA(m, ooxx)*AcA(m,ox);

Cit_CS(m, ooxxoo) = OAA(m, oxoo)*AcA(m,ox);
Cit_CS(m, xoxxoo) = OAA(m, oxox)*AcA(m,ox);
Cit_CS(m, oxxxoo) = OAA(m, oxxo)*AcA(m,ox);
Cit_CS(m, xxxxoo) = OAA(m, oxxx)*AcA(m,ox);

Cit_CS(m, ooooxo) = OAA(m, oooo)*AcA(m,xo);
Cit_CS(m, xoooxo) = OAA(m, ooox)*AcA(m,xo);
Cit_CS(m, oxooxo) = OAA(m, ooxo)*AcA(m,xo);
Cit_CS(m, xxooxo) = OAA(m, ooxx)*AcA(m,xo);

Cit_CS(m, ooxoxo) = OAA(m, oxoo)*AcA(m,xo);
Cit_CS(m, xoxoxo) = OAA(m, oxox)*AcA(m,xo);
Cit_CS(m, oxxoxo) = OAA(m, oxxo)*AcA(m,xo);
Cit_CS(m, xxxoxo) = OAA(m, oxxx)*AcA(m,xo);

Cit_CS(m, oooxxo) = OAA(m, oooo)*AcA(m,xx);
Cit_CS(m, xooxxo) = OAA(m, ooox)*AcA(m,xx);
Cit_CS(m, oxoxxo) = OAA(m, ooxo)*AcA(m,xx);
Cit_CS(m, xxoxxo) = OAA(m, ooxx)*AcA(m,xx);

Cit_CS(m, ooxxxo) = OAA(m, oxoo)*AcA(m,xx);
Cit_CS(m, xoxxxo) = OAA(m, oxox)*AcA(m,xx);
Cit_CS(m, oxxxxo) = OAA(m, oxxo)*AcA(m,xx);
Cit_CS(m, xxxxxo) = OAA(m, oxxx)*AcA(m,xx);

Cit_CS(m, ooooox) = OAA(m, xooo)*AcA(m,oo);
Cit_CS(m, xoooox) = OAA(m, xoox)*AcA(m,oo);
Cit_CS(m, oxooox) = OAA(m, xoxo)*AcA(m,oo);
Cit_CS(m, xxooox) = OAA(m, xoxx)*AcA(m,oo);

Cit_CS(m, ooxoox) = OAA(m, xxoo)*AcA(m,oo);
Cit_CS(m, xoxoox) = OAA(m, xxox)*AcA(m,oo);
Cit_CS(m, oxxoox) = OAA(m, xxxo)*AcA(m,oo);
Cit_CS(m, xxxoox) = OAA(m, xxxx)*AcA(m,oo);

Cit_CS(m, oooxox) = OAA(m, xooo)*AcA(m,ox);
Cit_CS(m, xooxox) = OAA(m, xoox)*AcA(m,ox);
Cit_CS(m, oxoxox) = OAA(m, xoxo)*AcA(m,ox);
Cit_CS(m, xxoxox) = OAA(m, xoxx)*AcA(m,ox);

Cit_CS(m, ooxxox) = OAA(m, xxoo)*AcA(m,ox);
Cit_CS(m, xoxxox) = OAA(m, xxox)*AcA(m,ox);
Cit_CS(m, oxxxox) = OAA(m, xxxo)*AcA(m,ox);
Cit_CS(m, xxxxox) = OAA(m, xxxx)*AcA(m,ox);

Cit_CS(m, ooooxx) = OAA(m, xooo)*AcA(m,xo);
Cit_CS(m, xoooxx) = OAA(m, xoox)*AcA(m,xo);
Cit_CS(m, oxooxx) = OAA(m, xoxo)*AcA(m,xo);
Cit_CS(m, xxooxx) = OAA(m, xoxx)*AcA(m,xo);

Cit_CS(m, ooxoxx) = OAA(m, xxoo)*AcA(m,xo);
Cit_CS(m, xoxoxx) = OAA(m, xxox)*AcA(m,xo);
Cit_CS(m, oxxoxx) = OAA(m, xxxo)*AcA(m,xo);
Cit_CS(m, xxxoxx) = OAA(m, xxxx)*AcA(m,xo);

Cit_CS(m, oooxxx) = OAA(m, xooo)*AcA(m,xx);
Cit_CS(m, xooxxx) = OAA(m, xoox)*AcA(m,xx);
Cit_CS(m, oxoxxx) = OAA(m, xoxo)*AcA(m,xx);
Cit_CS(m, xxoxxx) = OAA(m, xoxx)*AcA(m,xx);

Cit_CS(m, ooxxxx) = OAA(m, xxoo)*AcA(m,xx);
Cit_CS(m, xoxxxx) = OAA(m, xxox)*AcA(m,xx);
Cit_CS(m, oxxxxx) = OAA(m, xxxo)*AcA(m,xx);
Cit_CS(m, xxxxxx) = OAA(m, xxxx)*AcA(m,xx);

end

