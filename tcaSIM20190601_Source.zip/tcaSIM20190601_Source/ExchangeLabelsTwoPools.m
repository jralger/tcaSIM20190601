function [Mit, Cyt] = ExchangeLabelsTwoPools(Mit, Cyt, m, Cyt2Mit)
% Models exchange between mitochondrial labels (Mit) and cytosolic labels 
% (Cit) or more generally between any two general pools
% m is the TCA cycle turn number
% Mit and Cyt are float(nTCAturns, nIsotopomers)
% Mit and Cyt report relative isotopomer concentrations
% ie sum(Mit(m, :) = 1.0 for all m 
% and
% sum(Cyt(m, :) = 1.0 for all m 

% Cyt2Mit is the ratio of the two pools in an absolute sense
% eg if the Cyt pool is 20 times larger than the Cyt pool then Cyt2Mit = 20
% generally Cyt is larger than Mit, but the coding below allows the opposite
% if Cyt2Mit == 0 then no exchange is understood and Cit and Mit are
% returned unchanged
% the function should not be called with Cyt2Mit < 0 but if this happens 
% Cit and Mit are returned unchanged

% It is not neccessary to refer to the previous turn for the Cyt exchaning
% pool because Simulate Isotopomers prefills the exchanging pools at the
% end of each turn so that on entry
% Cyt(m, :) = Cyt(m-1, :)
% see lines 253 - 269 in SimulateIsotopomers

% JRA: 12/10/2018: previous version that used A and B for more generally 
% had a bug in which Mit and Cyt were switched at line 26
% decided to stay with Mit and Cyt for this reason



if Cyt2Mit > 0.0
    VMit = Mit(m, :);   % vectors: extract the labelling on current turn
    VCyt = Cyt(m, :);
    
    V = (Cyt2Mit*VCyt) + VMit;
    V = V/sum(V); % enforced the requirement that sum of all is 1.0
    
    Cyt(m,:) = V;
    Mit(m,:) = V;
end
end

