function [MMs, Sbs, SOs] = ReadtcaSIMInputCSV(FN)

% FN = 'C:\Users\Jeffry R Alger\Desktop\TCACalcUpDateDraft\TestFolder\tcaSIMInput.csv';
ExptIDs = ReadFluxModels(FN, 'ExptID', 0);
nExpts = size(ExptIDs, 2);
Ys = ReadFluxModels(FN, 'Ys', 1);
GlnYs = ReadFluxModels(FN, 'GlnYs', 1);
GK = ReadFluxModels(FN, 'GK', 1);
YPC = ReadFluxModels(FN, 'YPC', 1);
PDH = ReadFluxModels(FN, 'PDH', 1);
PK = ReadFluxModels(FN, 'PK', 1);
ROF = ReadFluxModels(FN, 'ROF', 1);
RSM = ReadFluxModels(FN, 'RSM', 1);
TPI = ReadFluxModels(FN, 'TPI', 1);
EaKG = ReadFluxModels(FN, 'EaKG', 1);
ECit = ReadFluxModels(FN, 'ECit', 1);
EOAA = ReadFluxModels(FN, 'EOAA', 1);
nTurns = ReadFluxModels(FN, 'nTurns', 1);
ExactNA = ReadFluxModels(FN, 'ExactNA', 1);

SkipAnimation = ReadFluxModels(FN, 'SkipAnimation', 1);
SkipMolLabelDiagram = ReadFluxModels(FN, 'SkipMolLabelDiagram', 1);
SkipStackedPlots = ReadFluxModels(FN, 'SkipStackedPlots', 1);
SkipAla = ReadFluxModels(FN, 'SkipAla', 1);
SkipAsp = ReadFluxModels(FN, 'SkipAsp', 1);
SkipbHB = ReadFluxModels(FN, 'SkipbHB', 1);
SkipMAG = ReadFluxModels(FN, 'SkipMAG', 1);
SkipGlu = ReadFluxModels(FN, 'SkipGlu', 1);

[oooo, xooo, oxoo, xxoo, ooxo, xoxo, oxxo, xxxo, ...
 ooox, xoox, oxox, xxox, ooxx, xoxx, oxxx, xxxx] = ... 
                                           DefineFourCarbonLabelIndices();
SuccYs = zeros(16, nExpts);                                       
               
SuccYs(xooo, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'xooo', nExpts);
SuccYs(oxoo, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'oxoo', nExpts);
SuccYs(xxoo, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'xxoo', nExpts);
               
SuccYs(ooxo, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'ooxo', nExpts);
SuccYs(xoxo, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'xoxo', nExpts);
SuccYs(oxxo, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'oxxo', nExpts);
SuccYs(xxxo, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'xxxo', nExpts);
               
SuccYs(ooox, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'ooox', nExpts);
SuccYs(xoox, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'xoox', nExpts);
SuccYs(oxox, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'oxox', nExpts);
SuccYs(xxox, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'xxox', nExpts);
               
SuccYs(ooxx, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'ooxx', nExpts);
SuccYs(xoxx, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'xoxx', nExpts);
SuccYs(oxxx, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'oxxx', nExpts);
SuccYs(xxxx, :) = ReadLabelledSubstrate(FN, 'SuccYs', 'xxxx', nExpts);

[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                               DefineThreeCarbonLabelIndices();
Glyc = zeros(8, nExpts);    

Glyc(xoo, :) = ReadLabelledSubstrate(FN, 'Glyc', 'xoo', nExpts);
Glyc(oxo, :) = ReadLabelledSubstrate(FN, 'Glyc', 'oxo', nExpts);
Glyc(xxo, :) = ReadLabelledSubstrate(FN, 'Glyc', 'xxo', nExpts);

Glyc(oox, :) = ReadLabelledSubstrate(FN, 'Glyc', 'oox', nExpts);
Glyc(xox, :) = ReadLabelledSubstrate(FN, 'Glyc', 'xox', nExpts);
Glyc(oxx, :) = ReadLabelledSubstrate(FN, 'Glyc', 'oxx', nExpts);
Glyc(xxx, :) = ReadLabelledSubstrate(FN, 'Glyc', 'xxx', nExpts);

Lac = zeros(8, nExpts);    

Lac(xoo, :) = ReadLabelledSubstrate(FN, 'Lac', 'xoo', nExpts);
Lac(oxo, :) = ReadLabelledSubstrate(FN, 'Lac', 'oxo', nExpts);
Lac(xxo, :) = ReadLabelledSubstrate(FN, 'Lac', 'xxo', nExpts);

Lac(oox, :) = ReadLabelledSubstrate(FN, 'Lac', 'oox', nExpts);
Lac(xox, :) = ReadLabelledSubstrate(FN, 'Lac', 'xox', nExpts);
Lac(oxx, :) = ReadLabelledSubstrate(FN, 'Lac', 'oxx', nExpts);
Lac(xxx, :) = ReadLabelledSubstrate(FN, 'Lac', 'xxx', nExpts);

[oo, xo, ox, xx] = DefineTwoCarbonLabelIndices();
FA = zeros(4, nExpts);    

FA(xo, :) = ReadLabelledSubstrate(FN, 'FA', 'xo', nExpts);
FA(ox, :) = ReadLabelledSubstrate(FN, 'FA', 'ox', nExpts);
FA(xx, :) = ReadLabelledSubstrate(FN, 'FA', 'xx', nExpts);

CO2 = zeros(2, nExpts); 
[o, x] = DefineOneCarbonLabelIndices();

CO2(x, :) = ReadLabelledSubstrate(FN, 'CO2', 'x', nExpts);

[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();

Gln = zeros(32, nExpts);  

Gln(xoooo, :) = ReadLabelledSubstrate(FN, 'Gln', 'xoooo', nExpts);
Gln(oxooo, :) = ReadLabelledSubstrate(FN, 'Gln', 'oxooo', nExpts);
Gln(xxooo, :) = ReadLabelledSubstrate(FN, 'Gln', 'xxooo', nExpts);

Gln(ooxoo, :) = ReadLabelledSubstrate(FN, 'Gln', 'ooxoo', nExpts);
Gln(xoxoo, :) = ReadLabelledSubstrate(FN, 'Gln', 'xoxoo', nExpts);
Gln(oxxoo, :) = ReadLabelledSubstrate(FN, 'Gln', 'oxxoo', nExpts);
Gln(xxxoo, :) = ReadLabelledSubstrate(FN, 'Gln', 'xxxoo', nExpts);

Gln(oooxo, :) = ReadLabelledSubstrate(FN, 'Gln', 'oooxo', nExpts);
Gln(xooxo, :) = ReadLabelledSubstrate(FN, 'Gln', 'xooxo', nExpts);
Gln(oxoxo, :) = ReadLabelledSubstrate(FN, 'Gln', 'oxoxo', nExpts);
Gln(xxoxo, :) = ReadLabelledSubstrate(FN, 'Gln', 'xxoxo', nExpts);

Gln(ooxxo, :) = ReadLabelledSubstrate(FN, 'Gln', 'ooxxo', nExpts);
Gln(xoxxo, :) = ReadLabelledSubstrate(FN, 'Gln', 'xoxxo', nExpts);
Gln(oxxxo, :) = ReadLabelledSubstrate(FN, 'Gln', 'oxxxo', nExpts);
Gln(xxxxo, :) = ReadLabelledSubstrate(FN, 'Gln', 'xxxxo', nExpts);

Gln(oooox, :) = ReadLabelledSubstrate(FN, 'Gln', 'oooox', nExpts);
Gln(xooox, :) = ReadLabelledSubstrate(FN, 'Gln', 'xooox', nExpts);
Gln(oxoox, :) = ReadLabelledSubstrate(FN, 'Gln', 'oxoox', nExpts);
Gln(xxoox, :) = ReadLabelledSubstrate(FN, 'Gln', 'xxoox', nExpts);

Gln(ooxox, :) = ReadLabelledSubstrate(FN, 'Gln', 'ooxox', nExpts);
Gln(xoxox, :) = ReadLabelledSubstrate(FN, 'Gln', 'xoxox', nExpts);
Gln(oxxox, :) = ReadLabelledSubstrate(FN, 'Gln', 'oxxox', nExpts);
Gln(xxxox, :) = ReadLabelledSubstrate(FN, 'Gln', 'xxxox', nExpts);

Gln(oooxx, :) = ReadLabelledSubstrate(FN, 'Gln', 'oooxx', nExpts);
Gln(xooxx, :) = ReadLabelledSubstrate(FN, 'Gln', 'xooxx', nExpts);
Gln(oxoxx, :) = ReadLabelledSubstrate(FN, 'Gln', 'oxoxx', nExpts);
Gln(xxoxx, :) = ReadLabelledSubstrate(FN, 'Gln', 'xxoxx', nExpts);

Gln(ooxxx, :) = ReadLabelledSubstrate(FN, 'Gln', 'ooxxx', nExpts);
Gln(xoxxx, :) = ReadLabelledSubstrate(FN, 'Gln', 'xoxxx', nExpts);
Gln(oxxxx, :) = ReadLabelledSubstrate(FN, 'Gln', 'oxxxx', nExpts);
Gln(xxxxx, :) = ReadLabelledSubstrate(FN, 'Gln', 'xxxxx', nExpts);

for i = 1:nExpts
    MM.ExptID = char(ExptIDs(1, i));
    MM.Ys = Ys(1,i);
    MM.GlnYs = GlnYs(1, i);
    MM.GK = GK(1, i);
    MM.YPC = YPC(1, i);
    MM.PDH = PDH(1, i);
    MM.PK = PK(1, i);
    MM.ROF = ROF(1, i);
    MM.RSM = RSM(1, i);
    MM.TPI = TPI(1, i);
    MM.EaKG = EaKG(1, i);
    MM.ECit = ECit(1, i);
    MM.EOAA = EOAA(1, i);
    MM.nTurns = nTurns(1, i);
    MM.ExactNaturalAbundance = ExactNA(1, i);
    MMs(i) = MM;
    
    Sb.SuccYs = UpdateUnLabelledIsotopomer(transpose(SuccYs(:, i)));
    Sb.Glyc = UpdateUnLabelledIsotopomer(transpose(Glyc(:, i)));
    Sb.Lac = UpdateUnLabelledIsotopomer(transpose(Lac(:, i)));
    Sb.Gln = UpdateUnLabelledIsotopomer(transpose(Gln(:, i)));
    Sb.FA = UpdateUnLabelledIsotopomer(transpose(FA(:, i)));
    Sb.CO2 = UpdateUnLabelledIsotopomer(transpose(CO2(:, i)));
    Sbs(i) = Sb;
    
    SO.SkipAnimation = SkipAnimation(1, i);
    SO.MultStackedPlots = SkipStackedPlots(1, i);
    SO.MolLabelDiagram = SkipMolLabelDiagram(1, i);
    SO.Ala = SkipAla(1, i);
    SO.Asp = SkipAsp(1, i);
    SO.bHB = SkipbHB(1, i);
    SO.MAG = SkipMAG(1, i);
    SO.Glu = SkipGlu(1, i);
    SOs(i) = SO;
end

end

