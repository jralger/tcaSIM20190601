function WriteExptParameters(ODN, Substrates, MetabolicModel)

FN = [ODN, '\', MetabolicModel.ExptID, '_tcaSIMInput.csv'];
fileID = fopen(FN, 'w');

% txt = ['SimulateIsotopomersID,,', VersionID, '\n'];
% fprintf(fileID, txt);

txt = ['ExptID,,', MetabolicModel.ExptID, '\n'];
fprintf(fileID, txt);

txt = ['PDH,,', num2str(MetabolicModel.PDH), '\n'];
fprintf(fileID, txt);

txt = ['YPC,,', num2str(MetabolicModel.YPC), '\n'];
fprintf(fileID, txt);

txt = ['Ys,,', num2str(MetabolicModel.Ys), '\n'];
fprintf(fileID, txt);

txt = ['GlnYs,,', num2str(MetabolicModel.GlnYs), '\n'];
fprintf(fileID, txt);

txt = ['PK,,', num2str(MetabolicModel.PK), '\n'];
fprintf(fileID, txt);

txt = ['GK,,', num2str(MetabolicModel.GK), '\n'];
fprintf(fileID, txt);

txt = ['ROF,,', num2str(MetabolicModel.ROF), '\n'];
fprintf(fileID, txt);

txt = ['RSM,,', num2str(MetabolicModel.RSM), '\n'];
fprintf(fileID, txt);

txt = ['TPI,,', num2str(MetabolicModel.TPI), '\n'];
fprintf(fileID, txt);

txt = ['EaKG,,', num2str(MetabolicModel.EaKG), '\n'];
fprintf(fileID, txt);

txt = ['ECit,,', num2str(MetabolicModel.ECit), '\n'];
fprintf(fileID, txt);

txt = ['EOAA,,', num2str(MetabolicModel.EOAA), '\n'];
fprintf(fileID, txt);

txt = ['nTurns,,', num2str(MetabolicModel.nTurns), '\n'];
fprintf(fileID, txt);

txt = ['ExactNA,,', num2str(MetabolicModel.ExactNaturalAbundance), '\n'];
fprintf(fileID, txt);

MID = 'CO2';
A = Substrates.CO2;
nA = size(A, 2);
IDs = BuildIsotopomerIDs(nA);
for i = 1:nA
    if A(1, i)
        T = char(IDs(i));
        if ~strcmp(T, 'o')
            txt = [MID, ','];
            txt = [txt, T, ','];
            txt = [txt, num2str(A(i)), '\n'];
            fprintf(fileID, txt);
        end
    end
end

MID = 'FA';
A = Substrates.FA;
nA = size(A, 2);
IDs = BuildIsotopomerIDs(nA);
for i = 1:nA
    if A(1, i)
        T = char(IDs(i));
        if ~strcmp(T, 'oo')
            txt = [MID, ','];
            txt = [txt, T, ','];
            txt = [txt, num2str(A(i)), '\n'];
            fprintf(fileID, txt);
        end
    end
end

MID = 'Lac';
A = Substrates.Lac;
nA = size(A, 2);
IDs = BuildIsotopomerIDs(nA);
for i = 1:nA
    if A(1, i)
        T = char(IDs(i));
        if ~strcmp(T, 'ooo')
            txt = [MID, ','];
            txt = [txt, T, ','];
            txt = [txt, num2str(A(i)), '\n'];
            fprintf(fileID, txt);
        end
    end
end

MID = 'Glyc';
A = Substrates.Glyc;
nA = size(A, 2);
IDs = BuildIsotopomerIDs(nA);
for i = 1:nA
    if A(1, i)
        T = char(IDs(i));
        if ~strcmp(T, 'ooo')
            txt = [MID, ','];
            txt = [txt, T, ','];
            txt = [txt, num2str(A(i)), '\n'];
            fprintf(fileID, txt);
        end
    end
end

MID = 'SuccYs';
A = Substrates.SuccYs;
nA = size(A, 2);
IDs = BuildIsotopomerIDs(nA);
for i = 1:nA
    if A(1, i)
        T = char(IDs(i));
        if ~strcmp(T, 'oooo')
            txt = [MID, ','];
            txt = [txt, T, ','];
            txt = [txt, num2str(A(i)), '\n'];
            fprintf(fileID, txt);
        end
    end
end

MID = 'Gln';
A = Substrates.Gln;
nA = size(A, 2);
IDs = BuildIsotopomerIDs(nA);
for i = 1:nA
    if A(1, i)
        T = char(IDs(i));
        if ~strcmp(T, 'ooooo')
            txt = [MID, ','];
            txt = [txt, T, ','];
            txt = [txt, num2str(A(i)), '\n'];
            fprintf(fileID, txt);
        end
    end
end

fclose(fileID);
dummy = 1;



