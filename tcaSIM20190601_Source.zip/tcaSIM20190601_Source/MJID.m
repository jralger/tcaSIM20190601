function R = MJID(V)
nV = size(V, 2);
R = V;
for i = 1:nV
    T = V(1, i);     
    if strncmp(T, 'o', 1)         
        R(1, i) = '#';
    end
    if strncmp(T, 'x', 1) 
        R(1, i) = num2str(i);
    end
end


end

