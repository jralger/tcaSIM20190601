function [handles, A] = ReadUpdateAllThreeCarbonIsotopomers(handles)

[ooo, xoo, oxo, xxo, oox, xox, oxx, xxx] = ...
                                    DefineThreeCarbonLabelIndices();
A = zeros(1,8);

A(1, xoo) = str2double(handles.XOO.String);
A(1, oxo) = str2double(handles.OXO.String);
A(1, xxo) = str2double(handles.XXO.String);

A(1, oox) = str2double(handles.OOX.String);
A(1, xox) = str2double(handles.XOX.String);
A(1, oxx) = str2double(handles.OXX.String);
A(1, xxx) = str2double(handles.XXX.String);

A = UpdateUnLabelledIsotopomer(A);

if A(1, ooo) < 0
    A = zeros(1, 8);
    A = UpdateUnLabelledIsotopomer(A);
end

handles.OOO.String = sprintf('%4.2f', A(1, ooo));
handles.XOO.String = sprintf('%4.2f', A(1, xoo));
handles.OXO.String = sprintf('%4.2f', A(1, oxo));
handles.XXO.String = sprintf('%4.2f', A(1, xxo));

handles.OOX.String = sprintf('%4.2f', A(1, oox));
handles.XOX.String = sprintf('%4.2f', A(1, xox));
handles.OXX.String = sprintf('%4.2f', A(1, oxx));
handles.XXX.String = sprintf('%4.2f', A(1, xxx));

end



