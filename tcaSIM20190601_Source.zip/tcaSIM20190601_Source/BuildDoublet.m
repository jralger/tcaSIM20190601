function Doublet = BuildDoublet(ID, Spectrum, FreqPPM, JHz, GlobalR2)

GlobalPhaseDeg = 0.0;
GlobalImagSign = '+';
GlobalSignalShape = 'Lorentz';
GlobalShapeParams = [GlobalR2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0];
GlobalSignalAmplitude = 1.0;
DefaultConc = 1.0;   
DefaultRelConc = 0.0;

Doublet.ID = ID;
Signal.FreqPPM = FreqPPM;
Signal.Amplitude = GlobalSignalAmplitude;
Signal.PhaseDeg = GlobalPhaseDeg;
Signal.Shape = GlobalSignalShape;
Signal.ShapeParams = GlobalShapeParams;
Signal.ImagSign = GlobalImagSign;

ScannerFreqMHz = Spectrum.ScannerFreqMHz;
JPPM = JHz/ScannerFreqMHz;

Signals = MakeDoublets(Signal, JPPM);

Doublet.Signals = Signals;
Doublet.JPPM = JPPM;
Doublet.Conc = DefaultConc;
Doublet.RelConc = DefaultRelConc;
Doublet.FreqPPM = FreqPPM;

SampleTimesSec = Spectrum.SampleTimesSec;
CenterPPM = Spectrum.CenterPPM;
Doublet = SimulateMultipletSpectrum(Doublet, ScannerFreqMHz, ...
                    SampleTimesSec, CenterPPM, GlobalImagSign);    
end

