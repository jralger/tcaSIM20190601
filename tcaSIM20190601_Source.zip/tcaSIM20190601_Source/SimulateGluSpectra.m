function Molecules = SimulateGluSpectra(Molecules, V)

[ooooo, xoooo, oxooo, xxooo, ...
 ooxoo, xoxoo, oxxoo, xxxoo, ...
 oooxo, xooxo, oxoxo, xxoxo, ...
 ooxxo, xoxxo, oxxxo, xxxxo, ...
 oooox, xooox, oxoox, xxoox, ...
 ooxox, xoxox, oxxox, xxxox, ...
 oooxx, xooxx, oxoxx, xxoxx, ...
 ooxxx, xoxxx, oxxxx, xxxxx] = DefineFiveCarbonLabelIndices();

nMols = size(Molecules, 2);
% Mol = Molecules(1, 1);
% for i = 1:nMols
%     Mol = Molecules(1, i);
%     ID = Mol.ID
% end

FE = GetFractionalEnrichment(V);

for i = 1:nMols
    Mol = Molecules(1, i);
    ID = Mol.ID;
    
    if strcmp(ID, 'Glu C1 S')
      Conc = V(xoooo) + V(xoxoo) + V(xooxo) + V(xoxxo) + ...
             V(xooox) + V(xoxox) + V(xooxx) + V(xoxxx);
      Mol.Conc = Conc;
      TotConc = FE(1);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C1 D')
      Conc = V(xxooo) + V(xxxoo) + V(xxoxo) + V(xxxxo) + ...
             V(xxoox) + V(xxxox) + V(xxoxx) + V(xxxxx);
      Mol.Conc = Conc;
      TotConc = FE(1);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C2 S')
      Conc = V(oxooo) + V(oxoxo) + V(oxoox) + V(oxoxx);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C2 D12')
      Conc = V(xxooo) + V(xxoxo) + V(xxoox) + V(xxoxx);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C2 D23')
      Conc = V(oxxoo) + V(oxxxo) + V(oxxox)+ V(oxxxx);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C2 Q')
      Conc = V(xxxoo) + V(xxxxo) + V(xxxox) + V(xxxxx);
      Mol.Conc = Conc;
      TotConc = FE(2);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C3 S')
      Conc = V(ooxoo) + V(xoxoo) + V(ooxox) + V(xoxox);
      Mol.Conc = Conc;
      TotConc = FE(3);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
%assumes C3 D23 and D34 are indistinguishable
    if strcmp(ID, 'Glu C3 D')
      Conc =  V(oxxoo) + V(xxxoo) + V(oxxox) + V(xxxox) + ...
              V(ooxxo) + V(xoxxo) + V(ooxxx) + V(xoxxx);
      Mol.Conc = Conc;
      TotConc = FE(3);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C3 T')
      Conc = V(oxxxo) + V(xxxxo) + V(oxxxx) +V(xxxxx);
      Mol.Conc = Conc;
      TotConc = FE(3);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C4 S')
      Conc = V(oooxo) + V(xooxo) + V(oxoxo) + V(xxoxo);
      Mol.Conc = Conc;
      TotConc = FE(4);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C4 D34')
      Conc = V(ooxxo) + V(xoxxo) + V(oxxxo) + V(xxxxo);
      Mol.Conc = Conc;
      TotConc = FE(4);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C4 D45')
      Conc = V(oooxx) + V(xooxx) + V(oxoxx) + V(xxoxx);
      Mol.Conc = Conc;
      TotConc = FE(4);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C4 Q')
      Conc = V(ooxxx) + V(xoxxx) + V(oxxxx) +V(xxxxx);
      Mol.Conc = Conc;
      TotConc = FE(4);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C5 S')
      Conc = V(oooox) + V(xooox) + V(oxoox) + V(xxoox) + ...
             V(ooxox) + V(xoxox) + V(oxxox) + V(xxxox);
      Mol.Conc = Conc;
      TotConc = FE(5);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
    if strcmp(ID, 'Glu C5 D')
      Conc = V(oooxx) + V(xooxx) + V(oxoxx) + V(xxoxx) + ...
             V(ooxxx) + V(xoxxx) + V(oxxxx) + V(xxxxx);
      Mol.Conc = Conc;
      TotConc = FE(5);
      if TotConc ~= 0.0
          Mol.RelConc = Conc/TotConc;
      end
      Molecules(1, i) = Mol;
    end
    
end

for i = 1:nMols
    Mol = Molecules(1, i);
    ID = Mol.ID;
    if contains(ID, 'Glu')
        NS = Mol.NormSpectrum;
        FD = NS.FreqDomainData;
        Conc = Mol.Conc;
        FD = FD*Conc;
        CWS = Mol.ConcWtdSpectrum;
        CWS.FreqDomainData = FD;
        Mol.ConcWtdSpectrum = CWS;
        Molecules(1, i) = Mol;
    end
end

% for i = 1:nMols
%     Mol = Molecules(1, i);
%     Conc = Mol.Conc
% end

end

